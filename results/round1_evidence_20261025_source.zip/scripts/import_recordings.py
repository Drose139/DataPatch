"""Import shipped actual recordings without making an API call."""
from __future__ import annotations

import json
from pathlib import Path

from datapatch.config import ROOT, Settings
from datapatch.service import write_json


def main():
    settings = Settings.load()
    imported = 0
    for source in sorted((ROOT / "examples/recorded_runs").glob("*.json")):
        record = json.loads(source.read_text(encoding="utf-8"))
        target = settings.artifacts_dir / "runs" / record["run_id"] / "run.json"
        if target.exists():
            continue
        write_json(target, record)
        imported += 1
    for source in sorted((ROOT / "results").glob("*.json")):
        target = settings.artifacts_dir / "evaluations" / source.name
        if not target.exists():
            write_json(target, json.loads(source.read_text(encoding="utf-8")))
    print(f"Imported {imported} actual recorded runs. No model calls were made.")


if __name__ == "__main__":
    main()
