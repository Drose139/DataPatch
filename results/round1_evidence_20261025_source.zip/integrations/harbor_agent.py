"""Native adapter for two pinned public data-eng-bench development cases.

This reproduces selected task inputs on a local dbt runtime. It does NOT claim
to be a Docker sandbox or an official Harbor leaderboard run. Evaluation stays
outside the agent's project and downloads no reference solution.
"""
from __future__ import annotations

import argparse
import hashlib
import importlib.metadata
import json
import os
import re
import shutil
import subprocess
import sys
import urllib.request
import zipfile
from datetime import datetime, timezone
from pathlib import Path

PUBLIC_TASK_MODELS = {
    "dbt-fix-refund-reconciliation": "models/marts/sales/rpt_return_reconciliation.sql",
    "dbt-fix-division-by-zero": "models/marts/customer/rpt_customer_metrics.sql",
}
PINNED_COMMIT = "a3278ad102829a6084dde086244a0ef665a8011c"
REPOSITORY = "Snowflake-Labs/data-eng-bench"


def runtime_versions() -> dict[str, str]:
    versions = {"python": sys.version.split()[0], "platform": sys.platform}
    for package in ("duckdb", "dbt-core", "dbt-duckdb"):
        try:
            versions[package] = importlib.metadata.version(package)
        except importlib.metadata.PackageNotFoundError:
            versions[package] = "not installed"
    return versions


def dbt_executable() -> str:
    executable = Path(sys.executable).parent / ("dbt.exe" if os.name == "nt" else "dbt")
    if executable.is_file():
        return str(executable)
    found = shutil.which("dbt")
    if not found:
        raise RuntimeError("dbt executable missing; install dbt-duckdb in the active Python environment")
    return found


def native_environment(case_dir: Path) -> dict[str, str]:
    case_dir = case_dir.resolve()
    env = os.environ.copy()
    env.update({"DB_TYPE": "duckdb", "DUCKDB_PATH": str(case_dir / "database" / "retail.duckdb"),
                "DBT_PROJECT_DIR_DUCKDB": str(case_dir / "project"), "DBT_PROFILES_DIR": str(case_dir / "project"),
                "DBT_SEND_ANONYMOUS_USAGE_STATS": "false", "PYTHONIOENCODING": "utf-8", "PYTHONUTF8": "1"})
    env["PATH"] = str(Path(sys.executable).parent) + os.pathsep + env.get("PATH", "")
    return env


def run_recorded(command: list[str], *, cwd: Path, env: dict[str, str], log: Path, timeout: int = 1200) -> None:
    result = subprocess.run(command, cwd=cwd, env=env, capture_output=True, text=True, encoding="utf-8", errors="replace", timeout=timeout)
    log.parent.mkdir(parents=True, exist_ok=True)
    log.write_text(json.dumps({"command": command, "returncode": result.returncode, "stdout": result.stdout, "stderr": result.stderr}, indent=2), encoding="utf-8")
    if result.returncode:
        raise RuntimeError(f"Preparation command failed ({result.returncode}); see {log}")


def prepare_native_case(snapshot: Path, case_dir: Path, task_id: str, *, initialize: bool = True, full_base_build: bool = False) -> dict:
    """Copy clean inputs, initialize ancestors, then inject the public buggy model."""
    if task_id not in PUBLIC_TASK_MODELS:
        raise ValueError(f"Supported fixed subset: {', '.join(PUBLIC_TASK_MODELS)}")
    snapshot, case_dir = snapshot.resolve(), case_dir.resolve()
    lock = json.loads((snapshot / "snapshot-lock.json").read_text(encoding="utf-8"))
    if lock["commit"] != PINNED_COMMIT or task_id not in lock["tasks"]:
        raise ValueError("Snapshot revision/subset does not match this adapter")
    source_database = snapshot / "base-image/database/retail.duckdb"
    if not source_database.is_file() or source_database.stat().st_size != lock["database"]["bytes"]:
        raise ValueError("Full DuckDB database missing; run fetch without --metadata-only")
    # Never reuse a case that may already contain a model's previous patch.
    if case_dir.exists() and any(case_dir.iterdir()):
        raise ValueError("Case directory must be empty; choose a fresh path for every independent attempt")
    case_dir.mkdir(parents=True, exist_ok=True)
    project = case_dir / "project"
    shutil.copytree(snapshot / "base-image/dbt_models_duckdb", project)
    database_dir = case_dir / "database"
    database_dir.mkdir()
    shutil.copy2(source_database, database_dir / "retail.duckdb")
    env = native_environment(case_dir)
    # Absolute path avoids changing dbt's database when the caller's cwd changes.
    # POSIX slashes are accepted by DuckDB on Windows and avoid YAML escaping.
    profile = "retail_dw_master:\n  target: dev\n  outputs:\n    dev:\n      type: duckdb\n      path: '" + (database_dir / "retail.duckdb").as_posix().replace("'", "''") + "'\n      schema: main\n      threads: 4\n"
    (project / "profiles.yml").write_text(profile, encoding="utf-8")
    logs = case_dir / "preparation"
    model_name = Path(PUBLIC_TASK_MODELS[task_id]).stem
    if initialize:
        run_recorded([sys.executable, str(snapshot / "base-image/fix_data.py")], cwd=project, env=env, log=logs / "fix_data.json")
        run_recorded([dbt_executable(), "deps", "--profiles-dir", str(project)], cwd=project, env=env, log=logs / "deps.json")
        command = [dbt_executable(), "run", "--profiles-dir", str(project), "--target", "dev"]
        if not full_base_build:
            command += ["--select", "+" + model_name]
        run_recorded(command, cwd=project, env=env, log=logs / "base_build.json")
    buggy = snapshot / "tasks" / task_id / "environment/data" / Path(PUBLIC_TASK_MODELS[task_id]).name
    shutil.copy2(buggy, project / PUBLIC_TASK_MODELS[task_id])
    instruction = (snapshot / "tasks" / task_id / "instruction.md").read_text(encoding="utf-8")
    instruction = instruction.replace("/app/dbt_models_duckdb", project.as_posix()).replace("/app/database/retail.duckdb", (database_dir / "retail.duckdb").as_posix())
    # The Snowflake path stays in the original task text to preserve its scope;
    # this preamble pins the backend and explains this native path translation.
    instruction = ("Native adapter has selected and verified the DuckDB backend (DB_TYPE=duckdb). "
                   "Use this project's existing profiles.yml; no shell tool is exposed, so the adapter replaces "
                   "the original echo-DB_TYPE setup step. Read/edit tool paths are relative to the task workspace.\n") + instruction
    (case_dir / "instruction.md").write_text(instruction, encoding="utf-8")
    metadata = {"task_id": task_id, "upstream_commit": PINNED_COMMIT, "mode": "native-adapted-public-development-case",
                "project_dir": str(project), "database_path": str(database_dir / "retail.duckdb"), "model": PUBLIC_TASK_MODELS[task_id],
                "initialized": initialize, "base_build": "all models" if full_base_build else "selected model and ancestors",
                "runtime": runtime_versions(), "path_translations": {"/app/dbt_models_duckdb": str(project), "/app/database/retail.duckdb": str(database_dir / "retail.duckdb")},
                "official_harbor_result": False, "hidden_verifier_used_by_agent": False}
    (case_dir / "native-case.json").write_text(json.dumps(metadata, indent=2) + "\n", encoding="utf-8")
    return metadata


def evaluate_native_case(case_dir: Path, evaluator_root: Path) -> dict:
    """Run upstream's original verifier once, after agent execution has stopped.

    Only absolute /app paths are translated. The source and adapted hashes are
    recorded. The evaluator directory must remain outside the agent case.
    """
    case_dir, evaluator_root = case_dir.resolve(), evaluator_root.resolve()
    if evaluator_root == case_dir or case_dir in evaluator_root.parents:
        raise ValueError("Verifier directory must be outside the agent's case directory")
    meta = json.loads((case_dir / "native-case.json").read_text(encoding="utf-8"))
    if meta["upstream_commit"] != PINNED_COMMIT or meta["task_id"] not in PUBLIC_TASK_MODELS:
        raise ValueError("Unexpected native case revision/task")
    task_id = meta["task_id"]
    evaluator_dir = evaluator_root / task_id
    evaluator_dir.mkdir(parents=True, exist_ok=True)
    url = f"https://raw.githubusercontent.com/{REPOSITORY}/{PINNED_COMMIT}/tasks/{task_id}/tests/test_outputs.py"
    with urllib.request.urlopen(urllib.request.Request(url, headers={"User-Agent": "DataPatch-final-evaluator/0.1"}), timeout=90) as response:
        source = response.read()
    (evaluator_dir / "test_outputs.original.py").write_bytes(source)
    verifier_logs = evaluator_dir / (case_dir.name + "-logs")
    adapted = source.decode("utf-8").replace("/app/dbt_models_duckdb", (case_dir / "project").as_posix()).replace("/app/database/retail.duckdb", (case_dir / "database/retail.duckdb").as_posix()).replace("/logs/verifier", verifier_logs.as_posix())
    evaluator = evaluator_dir / "test_outputs_native.py"
    evaluator.write_text(adapted, encoding="utf-8")
    result = subprocess.run([sys.executable, "-m", "pytest", "-q", "-s", str(evaluator)], cwd=evaluator_dir, env=native_environment(case_dir), capture_output=True, text=True, encoding="utf-8", errors="replace", timeout=3000)
    reward_path = verifier_logs / "reward.json"
    reward = json.loads(reward_path.read_text(encoding="utf-8")).get("reward") if reward_path.exists() else None
    passed = re.findall(r"^PASS: (component_\w+)", result.stdout, re.M)
    failed = re.findall(r"^FAIL: (component_\w+)", result.stdout, re.M)
    report = {"task_id": task_id, "mode": "native-path-adapted-upstream-verifier", "official_harbor_result": False,
              "upstream_commit": PINNED_COMMIT, "source_url": url, "original_sha256": hashlib.sha256(source).hexdigest(),
              "adapted_sha256": hashlib.sha256(adapted.encode()).hexdigest(), "path_translation_only": True,
              "returncode": result.returncode, "reward": reward, "components_passed": passed, "components_failed": failed,
              "stdout": result.stdout, "stderr": result.stderr}
    output = evaluator_dir / f"{case_dir.name}-evaluation.json"
    output.write_text(json.dumps(report, indent=2) + "\n", encoding="utf-8")
    return {"report": str(output), "returncode": result.returncode, "reward": reward, "components_passed": len(passed), "components_failed": len(failed), "stdout_tail": result.stdout[-2500:]}


def run_native_case(case_dir: Path, result_root: Path, *, mode: str = "verified", max_steps: int | None = None, budget_usd: float | None = None, source_snapshot: Path | None = None) -> dict:
    """Execute DataPatch only; upstream verifier results never enter its context."""
    from datapatch.agent import Agent, AGENT_REVISION
    from datapatch.config import Settings
    from datapatch.evaluation import source_digest
    from datapatch.workspace import Workspace

    case_dir, result_root = case_dir.resolve(), result_root.resolve()
    if result_root == case_dir or case_dir in result_root.parents:
        raise ValueError("Result directory must be outside the agent's case directory")
    meta = json.loads((case_dir / "native-case.json").read_text(encoding="utf-8"))
    if not meta["initialized"]:
        raise ValueError("Initialize the dbt ancestors before asking the agent to run")
    result_root.mkdir(parents=True, exist_ok=True)
    prefix = result_root / f"{case_dir.name}-{mode}"
    if prefix.with_suffix(".json").exists():
        raise ValueError("A result already exists; each independent trial needs a fresh prepared case")
    config = Settings.load()
    if max_steps is not None:
        config.max_steps = max_steps
    if budget_usd is not None:
        config.run_budget_usd = budget_usd
    workspace = Workspace(case_dir, project_dir=case_dir / "project", database_path=case_dir / "database/retail.duckdb")
    workspace.default_select = "+" + Path(PUBLIC_TASK_MODELS[meta["task_id"]]).stem
    event_path = prefix.with_suffix(".jsonl")
    core_source_sha256 = source_digest()
    snapshot_sha256 = None
    if source_snapshot is not None:
        source_snapshot = source_snapshot.resolve()
        with zipfile.ZipFile(source_snapshot) as archive:
            manifest = json.loads(archive.read("source-manifest.json"))
        if manifest["core_source_sha256"] != core_source_sha256:
            raise ValueError("Source snapshot does not match the current core; freeze the implementation before running")
        snapshot_sha256 = hashlib.sha256(source_snapshot.read_bytes()).hexdigest()
    with event_path.open("w", encoding="utf-8") as events:
        def emit(event: dict) -> None:
            events.write(json.dumps(event, ensure_ascii=False, default=str) + "\n")
            events.flush()
            if event.get("type") == "tool":
                print(f"tool {event.get('name')} step={event.get('step')}", flush=True)
            elif event.get("type") == "model":
                print(f"model call tokens={event.get('usage', {}).get('total_tokens', '?')}", flush=True)
        agent = Agent(workspace, config, mode=mode, emit=emit, focus_model=Path(PUBLIC_TASK_MODELS[meta["task_id"]]).stem)
        try:
            result = agent.run((case_dir / "instruction.md").read_text(encoding="utf-8"))
        except Exception as exc:
            result = {"error": str(exc), "error_type": type(exc).__name__, "metrics": agent.metrics}
    report = {"benchmark": "data-eng-bench", "task_id": meta["task_id"], "commit": meta["upstream_commit"],
              "mode": mode, "model": config.model, "max_steps": config.max_steps, "budget_usd": config.run_budget_usd,
              "source_sha256": core_source_sha256,
              "agent_revision": AGENT_REVISION,
              "source_snapshot": str(source_snapshot) if source_snapshot is not None else None,
              "source_snapshot_sha256": snapshot_sha256,
              "setting": meta["mode"], "official_harbor_result": False, "result": result, "events": str(event_path)}
    prefix.with_suffix(".json").write_text(json.dumps(report, indent=2, ensure_ascii=False, default=str) + "\n", encoding="utf-8")
    prefix.with_suffix(".patch").write_text(workspace.diff(), encoding="utf-8")
    return {"report": str(prefix.with_suffix('.json')), "result": result}


def render_public_summary(case_dir: Path, result_root: Path, evaluator_root: Path, output: Path, *, mode: str = "verified") -> dict:
    """Package actual native results for the same reports UI as local evaluations."""
    from datapatch.evaluation import render_report, summarize

    case_dir = case_dir.resolve()
    meta = json.loads((case_dir / "native-case.json").read_text(encoding="utf-8"))
    agent_path = result_root / f"{case_dir.name}-{mode}.json"
    verifier_path = evaluator_root / meta["task_id"] / f"{case_dir.name}-evaluation.json"
    agent_report = json.loads(agent_path.read_text(encoding="utf-8"))
    verifier = json.loads(verifier_path.read_text(encoding="utf-8"))
    valid_test_execution = bool(verifier.get("components_passed") or verifier.get("components_failed")) and verifier.get("reward") is not None
    passed = valid_test_execution and verifier["reward"] == 1.0 and verifier["returncode"] == 0
    record = {"run_id": f"{case_dir.name}-{mode}", "task_id": meta["task_id"], "mode": mode, "repeat": 0,
              "status": "completed" if valid_test_execution else "failed", "metrics": agent_report["result"].get("metrics", {}),
              "model": agent_report["model"], "max_steps": agent_report["max_steps"], "budget_usd": agent_report["budget_usd"],
              "source_sha256": agent_report.get("source_sha256"),
              "agent_revision": agent_report.get("agent_revision"),
              "source_snapshot": agent_report.get("source_snapshot"), "source_snapshot_sha256": agent_report.get("source_snapshot_sha256"),
              "stop_reason": agent_report["result"].get("stop_reason"), "final_answer": agent_report["result"].get("final_answer", ""),
              "verification": {"passed": bool(passed), "reward": verifier.get("reward"), "components_passed": verifier.get("components_passed", []), "components_failed": verifier.get("components_failed", []), "valid_pytest_execution": valid_test_execution},
              "final_build": {"success": "component_1_model_compiles" in verifier.get("components_passed", [])},
              "agent_report": str(agent_path.resolve()), "verifier_report": str(verifier_path.resolve()), "raw_verifier": verifier}
    previous = json.loads(output.read_text(encoding="utf-8")) if output.exists() else {}
    records = [row for row in previous.get("records", []) if row["run_id"] != record["run_id"]]
    for row in records:
        row.setdefault("max_steps", previous.get("protocol", {}).get("max_steps"))
    records.append(record)
    report = {"name": output.stem, "title": "data-eng-bench 公开开发任务：本地适配实际结果（非官方成绩）",
              "created_at": datetime.now(timezone.utc).isoformat(), "dataset": "snowflake-data-eng-bench/native-public-development-subset",
              "provenance": "Snowflake-Labs/data-eng-bench 固定公开开发题；原始数据、dbt项目和任务说明，Windows native路径适配；非官方Docker/Harbor成绩，非未知保留集。",
              "upstream_repository": f"https://github.com/{REPOSITORY}", "upstream_commit": PINNED_COMMIT, "official_harbor_result": False,
              "protocol": {"task_ids": list(dict.fromkeys(row["task_id"] for row in records)), "planned_task_ids": list(PUBLIC_TASK_MODELS), "modes": list(dict.fromkeys(row["mode"] for row in records)), "repeats": 1, "model": agent_report["model"],
                           "max_steps_by_task": {row["task_id"]: row.get("max_steps") for row in records}, "budget_usd": agent_report["budget_usd"], "hidden_feedback_to_agent": False,
                           "source_sha256_by_trial": {row["run_id"]: row.get("source_sha256") for row in records},
                           "agent_revision_by_trial": {row["run_id"]: row.get("agent_revision") for row in records},
                           "cost_is_estimate": True, "path_translation_only_in_verifier": True, "base_build": meta["base_build"], "runtime": meta["runtime"],
                           "initial_adapter_issue": "A direct Python invocation only defined test functions; it was not counted as a score. This report uses the subsequent actual pytest execution."},
              "limitations": [f"Only {len(records)} public development trial(s), one per task; no performance/generalization claim.",
                              "Native Windows/dbt versions and selected-ancestor initialization differ from the official Linux Docker environment.",
                              "Task success requires every upstream component to pass; partial component credit is descriptive only.",
                              "No React comparison was run; these are development executions rather than an ablation experiment."],
              "status": "completed" if len(records) == len(PUBLIC_TASK_MODELS) else "running", "planned_trials": len(PUBLIC_TASK_MODELS), "records": records, "summary": summarize(records)}
    if any(row.get("stop_reason") == "step_limit" for row in records):
        report["limitations"].append("At least one execution reached the model step limit; inspect per-trial action logs before claiming completed delivery.")
    output.parent.mkdir(parents=True, exist_ok=True)
    output.write_text(json.dumps(report, indent=2, ensure_ascii=False) + "\n", encoding="utf-8")
    render_report(report, output.with_suffix(".md"))
    with output.with_suffix(".md").open("a", encoding="utf-8") as markdown:
        markdown.write("\n## 外部任务验收与限制\n\n")
        markdown.write(f"固定 commit：`{PINNED_COMMIT}`；模型：`{agent_report['model']}`。\n\n")
        markdown.write("| 任务 | 最大步数 | 停止原因 | 上游组件通过/总数 | 二元reward |\n|---|---:|---|---:|---:|\n")
        for row in records:
            verification = row["verification"]
            component_count = len(verification["components_passed"]) + len(verification["components_failed"])
            markdown.write(f"| {row['task_id']} | {row.get('max_steps')} | {row['stop_reason']} | {len(verification['components_passed'])}/{component_count} | {verification['reward']} |\n")
        markdown.write("\n")
        for limitation in report["limitations"]:
            markdown.write(f"- {limitation}\n")
        for row in records:
            markdown.write("\n### " + row["task_id"] + "\n\n原始 pytest 输出（只进行路径重映射，未改测试断言）：\n\n```text\n" + row["raw_verifier"]["stdout"] + "\n```\n")
    return {"report": str(output.resolve()), "summary": report["summary"], "valid_pytest_execution": valid_test_execution}


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    sub = parser.add_subparsers(dest="command", required=True)
    prepare = sub.add_parser("prepare")
    prepare.add_argument("--snapshot", type=Path, default=Path("external/data-eng-bench"))
    prepare.add_argument("--case", type=Path, required=True)
    prepare.add_argument("--task", choices=PUBLIC_TASK_MODELS, default="dbt-fix-refund-reconciliation")
    prepare.add_argument("--skip-initialize", action="store_true")
    prepare.add_argument("--full-base-build", action="store_true")
    evaluate = sub.add_parser("evaluate")
    evaluate.add_argument("--case", type=Path, required=True)
    evaluate.add_argument("--evaluator-root", type=Path, default=Path("external/public-verifiers"))
    run = sub.add_parser("run")
    run.add_argument("--case", type=Path, required=True)
    run.add_argument("--result-root", type=Path, default=Path("external/native-results"))
    run.add_argument("--mode", choices=("baseline", "react", "context", "verified"), default="verified")
    run.add_argument("--max-steps", type=int)
    run.add_argument("--budget-usd", type=float, help="Override this run only; does not modify shared .env")
    run.add_argument("--source-snapshot", type=Path, help="Source zip whose manifest must match the current core")
    report = sub.add_parser("report")
    report.add_argument("--case", type=Path, required=True)
    report.add_argument("--result-root", type=Path, default=Path("external/native-results"))
    report.add_argument("--evaluator-root", type=Path, default=Path("external/public-verifiers"))
    report.add_argument("--mode", default="verified")
    report.add_argument("--output", type=Path, default=Path("artifacts/evaluations/public_native_subset_20261025.json"))
    args = parser.parse_args()
    if args.command == "prepare":
        result = prepare_native_case(args.snapshot, args.case, args.task, initialize=not args.skip_initialize, full_base_build=args.full_base_build)
    elif args.command == "evaluate":
        result = evaluate_native_case(args.case, args.evaluator_root)
    elif args.command == "run":
        result = run_native_case(args.case, args.result_root, mode=args.mode, max_steps=args.max_steps, budget_usd=args.budget_usd, source_snapshot=args.source_snapshot)
    else:
        result = render_public_summary(args.case, args.result_root, args.evaluator_root, args.output, mode=args.mode)
    print(json.dumps(result, indent=2, ensure_ascii=False))


if __name__ == "__main__":
    main()
