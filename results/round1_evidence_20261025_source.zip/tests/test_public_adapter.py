from __future__ import annotations

import importlib.util
import io
import json
from pathlib import Path

import pytest


def module_from_path(name: str, path: str):
    spec = importlib.util.spec_from_file_location(name, Path(__file__).parents[1] / path)
    module = importlib.util.module_from_spec(spec)
    assert spec.loader is not None
    spec.loader.exec_module(module)
    return module


fetch = module_from_path("benchmark_fetch", "scripts/fetch_public_benchmark.py")
adapter = module_from_path("benchmark_adapter", "integrations/harbor_agent.py")


def test_fetch_allowlist_excludes_answers_and_other_tasks():
    tasks = ("dbt-fix-refund-reconciliation",)
    assert fetch.selected_path("base-image/dbt_models_duckdb/tests/generic/test_not_null.sql", tasks)
    assert fetch.selected_path("tasks/dbt-fix-refund-reconciliation/environment/data/rpt_return_reconciliation.sql", tasks)
    for path in (
        "tasks/dbt-fix-refund-reconciliation/solution/solve.sh",
        "tasks/dbt-fix-refund-reconciliation/tests/test_outputs.py",
        "tasks/another-task/instruction.md",
        "base-image/dbt_models_duckdb/../../solution/solve.sh",
    ):
        assert not fetch.selected_path(path, tasks)


def test_prepare_overlays_bug_without_copying_private_material(tmp_path):
    snapshot = tmp_path / "snapshot"
    task_id = "dbt-fix-refund-reconciliation"
    target = adapter.PUBLIC_TASK_MODELS[task_id]
    original = snapshot / "base-image/dbt_models_duckdb" / target
    original.parent.mkdir(parents=True)
    original.write_text("select 'base' as state", encoding="utf-8")
    (snapshot / "base-image/database").mkdir()
    (snapshot / "base-image/database/retail.duckdb").write_bytes(b"test-database")
    task = snapshot / "tasks" / task_id
    (task / "environment/data").mkdir(parents=True)
    (task / "environment/data" / Path(target).name).write_text("select 'bug' as state", encoding="utf-8")
    (task / "instruction.md").write_text("Edit /app/dbt_models_duckdb/" + target, encoding="utf-8")
    (task / "solution").mkdir()
    (task / "solution/solve.sh").write_text("secret-reference", encoding="utf-8")
    (snapshot / "snapshot-lock.json").write_text(json.dumps({"commit": adapter.PINNED_COMMIT, "tasks": [task_id], "database": {"bytes": 13}}), encoding="utf-8")
    case = tmp_path / "case"
    metadata = adapter.prepare_native_case(snapshot, case, task_id, initialize=False)
    assert metadata["official_harbor_result"] is False
    assert (case / "project" / target).read_text(encoding="utf-8") == "select 'bug' as state"
    assert not list(case.rglob("solve.sh"))
    assert "/app/dbt_models_duckdb" not in (case / "instruction.md").read_text(encoding="utf-8")
    with pytest.raises(ValueError, match="empty"):
        adapter.prepare_native_case(snapshot, case, task_id, initialize=False)


def test_final_verifier_must_live_outside_agent_case(tmp_path):
    case = tmp_path / "case"
    case.mkdir()
    with pytest.raises(ValueError, match="outside"):
        adapter.evaluate_native_case(case, case / "hidden-tests")


def test_evaluator_really_invokes_pytest_and_preserves_binary_failure(tmp_path, monkeypatch):
    case = tmp_path / "case"
    case.mkdir()
    (case / "native-case.json").write_text(json.dumps({"task_id": "dbt-fix-refund-reconciliation", "upstream_commit": adapter.PINNED_COMMIT}), encoding="utf-8")
    # Like upstream, importing/running this module directly executes no test.
    source = b'''from pathlib import Path
def test_solution():
    print("PASS: component_1_model_compiles")
    print("FAIL: component_2_business_rule: counterexample")
    output = Path("/logs/verifier")
    output.mkdir(parents=True, exist_ok=True)
    (output / "reward.json").write_text('{"reward": 0.0}')
    assert False, "binary task failed despite a passing component"
'''
    monkeypatch.setattr(adapter.urllib.request, "urlopen", lambda *a, **k: io.BytesIO(source))
    result = adapter.evaluate_native_case(case, tmp_path / "evaluators")
    assert result["returncode"] == 1
    assert result["reward"] == 0.0
    assert result["components_passed"] == result["components_failed"] == 1
