# 外部公开任务：data-eng-bench

DataPatch 的外部验证使用 [Snowflake-Labs/data-eng-bench](https://github.com/Snowflake-Labs/data-eng-bench) 的公开任务。当前本地适配固定在 commit `a3278ad102829a6084dde086244a0ef665a8011c`，固定开发子集为：

- `dbt-fix-refund-reconciliation`
- `dbt-fix-division-by-zero`

这两题属于**公开开发案例**，用于核实能否在独立来源的真实 dbt 项目上运行；不能用两题结果估计全量 103 题效果。研究选题时已查看过这两题的公开说明，不能称为未见保留集。

## 下载与来源记录

```powershell
& '.venv/Scripts/python.exe' 'scripts/fetch_public_benchmark.py'
```

脚本从固定 commit 流式读取上游压缩归档，只提取 DuckDB dbt 项目、原始数据库指针、运行时数据修正脚本、许可证和选定任务的初始输入。`solution/` 和任务 `tests/` 不提取、不保存；归档本身不落盘。dbt 项目自带的通用可见测试属于原运行环境，会保留。

原始 `retail.duckdb` 为 488,910,848 字节，通过 Git LFS 对象 SHA-256 检查。所有提取文件的 SHA-256、大小、commit、任务名单写入 `external/data-eng-bench/snapshot-lock.json`。`external/` 不进入 Git。`--metadata-only` 可以跳过大数据库下载。

该数据库固定 SHA-256：`bd2bb1b3a7cf62aa94c191527aa30db5bf415aea97db718a1e0c11c59fc2ec2d`。

## 本地适配运行

本机只读环境检查未发现 `docker` 命令或 Docker Desktop 标准安装路径；WSL 命令存在，但没有列出可用发行版。未安装或启动系统服务。因此当前支持 **native adapted** 路径，执行受信任公开 dbt 项目；它不提供操作系统沙箱隔离。

先安装项目依赖并设置 `.env` 中的 API 配置，然后准备一个全新的试验目录：

```powershell
& '.venv/Scripts/python.exe' 'integrations/harbor_agent.py' 'prepare' '--case' 'external/native-cases/refund-verified-01' '--task' 'dbt-fix-refund-reconciliation'
& '.venv/Scripts/python.exe' 'integrations/harbor_agent.py' 'run' '--case' 'external/native-cases/refund-verified-01' '--mode' 'verified' '--max-steps' '35'
```

每次独立试验必须使用全新的 case 目录，不复用 Agent 修改过的文件或数据库。准备流程复制原 dbt 项目和原始数据，运行上游 `fix_data.py`，执行 `dbt deps`，构建目标模型及其祖先，然后覆盖该任务提供的故障 SQL。`--full-base-build` 可改为全项目初始化；默认只初始化相关模型以降低本地时间成本。

`run` 调用项目自己的 `Workspace` 与 `Agent`。事件、模型名、预算、运行结果和 patch 保存至 `external/native-results/`，不进入 Agent 的文件工具根目录。Agent 只能访问 case 下的业务输入，没有最终 verifier 或参考解法。

## 最终验收

Agent 运行结束后，单独执行：

```powershell
& '.venv/Scripts/python.exe' 'integrations/harbor_agent.py' 'evaluate' '--case' 'external/native-cases/refund-verified-01'
```

此时才下载原任务 `tests/test_outputs.py` 到 case 外的 `external/public-verifiers/`。为在 Windows 本地运行，只将原验收代码中的绝对 `/app/` 项目、数据库路径以及 `/logs/verifier` 输出路径重映射；保存原文件、重映射文件及各自 SHA-256。通过 `python -m pytest -q -s` 真正执行上游 `test_solution`，记录各 component 的结果和原始 `reward.json`。测试断言不改写，失败日志不返回给 Agent 继续优化。**直接 `python test_outputs.py` 只会定义函数，不能构成有效验收；退出码 0 本身也不等于任务通过。**

若依据验收结果修改了 Agent 或提示词，后续运行属于这两道开发题上的迭代，不属于一次性未见测试。要报告泛化效果，需要另选预先登记的任务，并在配置冻结后运行。

## 与官方设置的差异

| 项目 | 当前本地路径 | 官方 Harbor 路径 |
|---|---|---|
| 环境 | Windows 本地 Python/dbt，记录实际版本 | Linux Docker，官方基础镜像及依赖 |
| 初始化 | 默认目标模型及祖先；可选全量 | 基础镜像中全项目 `dbt run` |
| 文件路径 | `/app/` 路径重映射 | 原路径 |
| Agent | DataPatch 有边界的文件/SQL/dbt工具 | 通过 Harbor agent integration |
| 验收 | 原始断言，路径适配，Agent结束后单独执行 | Harbor 注入原始 verifier |
| 结果名称 | 固定公开开发子集、本地适配结果 | 官方对应后端全量/声明子集结果 |

**本地结果不能标为官方 Harbor 榜单成绩。** 上游全量榜至少要求每题三次独立试验；平均单次成功率与三次全部成功的一致性分开报告。上游 README 还指出 `dbt-fix-timezone-sales` 的 DuckDB 验收可能受执行顺序影响，这也是后续扩大集合时必须单独说明的问题。

标准运行以[上游 README](https://github.com/Snowflake-Labs/data-eng-bench/blob/master/README.md) 为准；[Harbor 文档](https://docs.harborframework.com/agents/pre-integrated-agents)提供通用 Agent 和自定义 Agent 的正式入口。本项目尚未宣称完成 Docker/Harbor 全量跑分。

## 已保留的实际失败

2026-10-25 的固定两题公开开发子集实际结果如下；模型均为 `deepseek-flash`，每题独立原始工作目录、只运行一次，不根据最终验收回传重试：

| 任务 | 最大步数 | 原验收组件通过 | 任务二元reward | 模型调用 | 停止原因 | 估算USD |
|---|---:|---:|---:|---:|---|---:|
| refund-reconciliation | 24 | 12/13 | 0 | 24 | step_limit | 0.301547 |
| division-by-zero | 16 | 1/15 | 0 | 16 | step_limit | 0.208002 |

**任务通过 0/2**；共 40 次模型调用、66 次工具调用、1,672,068 Tokens，配置单价估算总费用 0.509549 USD。两题最大步数不同，属于开发实测记录；没有进行模式对照或重复运行，不据此作泛化或显著性结论。

首次退款对账任务运行中，DeepSeek 已产生补丁，模型能够编译执行；上游 13 个组件通过 12 个，但 `component_8_waterfall_tier_logic` 失败，所以整个任务二元 reward 为 0。Agent 还重复执行同一条已经成功返回的查询，直至 24 步上限，未完成最终自然语言交付。

验收结束后的人工分析发现：SQL 写成 `CASE WHEN total_processing_days IS NOT NULL THEN PERCENT_RANK() OVER (...) END`，仅把 NULL 行的最终结果置空，NULL 行仍进入窗口总体；任务要求分位数只在非 NULL 记录中计算。因此窗口分母错误，若干记录的退款分层错误。编译通过、无 inf/NaN 和正确列结构，都不能代替这项业务语义检查。

这个原因没有反馈给同一 Agent 继续重跑，也没有把失败补丁手工修成“成功演示”。当前实现保留重复工具调用和预算耗尽的限制；后续可以把停滞检测、窗口计算总体的可见契约作为明确改进，再用新的保留任务验证效果。原始上游反馈和模型成本见 `artifacts/evaluations/public_native_subset_20261025.json`。

第二题在 16 步内一直探索和查询数据，没有产生模型文件修改。最终验收只通过编译组件；目标新增列缺失以及原始数据问题仍在，其余 14 个组件失败。这是预算内没有从探索推进到交付的失败，不能描述为已经实现了客户指标修复。

## v2 同题开发重测

v2 改为目标模型及相关依赖的聚焦上下文，并加入连续读取、相同结果和剩余调用预算的通用进度提醒。没有向模型提供原验收代码、反例或参考补丁。两题使用全新原始工作目录，保留 v1 各题的步数上限；本次每 run 费用上限为 0.25 USD，两次均未触发。

| 任务 | 原验收组件通过 | 任务二元reward | 调用/工具数 | Tokens | 估算USD |
|---|---:|---:|---:|---:|---:|
| refund-reconciliation | 12/13 | 0 | 24/31 | 300731 | 0.093669 |
| division-by-zero | 14/15 | 0 | 16/20 | 232688 | 0.074458 |

v2 **任务通过仍为 0/2**。总 Tokens 减少 68.1%、估算费用减少 67.0%，但不能写成任务成功率提高。两次仍到达步数上限，分别触发一次停滞提醒；客户指标题已能在预算内生成和执行补丁。

验收后的人工分析发现：退款题的 `NULLS LAST` 仍未排除 NULL 行参与排名总体；客户指标题把原有 `status != 'CANCELLED'` 变成 `upper(status) <> 'CANCELLED'`，擅自改变大小写过滤语义，导致少 2 位客户。聚焦上下文和提醒解决了部分执行效率问题，还需要更可靠的业务契约核对与保留既有语义。

完整原验收输出见 `artifacts/evaluations/public_native_v2_20261025.json` 和同名 `.md`。运行前冻结的源码为 `public_native_v2_20261025_source.zip`，core SHA-256 为 `7fb8fb2152886b376b5b6a16f962c244eb1033228a2ec3f8f69d2a2d1949cde7`。这是同题公开开发集重测，不能称为盲测、保留集或未知任务泛化结果。
