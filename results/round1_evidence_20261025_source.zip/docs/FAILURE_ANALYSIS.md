# DataPatch v1：真实失败、证据与修订

本页记录 2026-10-25 的实际运行与代码审阅发现。模型失败、执行环境故障和评分漏洞分别处理；修好了基础设施或评分器，不等于模型任务表现已经提高。

## 数据来源与实验边界

外部开发案例来自 [Snowflake-Labs/data-eng-bench](https://github.com/Snowflake-Labs/data-eng-bench)，固定 commit 为 `a3278ad102829a6084dde086244a0ef665a8011c`。两题在独立的初始项目目录运行，使用真实 `deepseek-flash`；结束后单独执行上游原始 pytest 断言。适配只重映射本机路径，没有把最终验收反馈送回原次运行中的 Agent。

这是 Windows native 路径的两道**公开开发题**，不是 Docker/Harbor 官方成绩，也不是未见保留任务上的泛化证明。两题步数上限不同，每题仅一次，没有运行模式对照或重复实验。

原始证据：

- 汇总：`artifacts/evaluations/public_native_subset_20261025.json`。
- 退款任务：`external/native-results/refund-verified-02-verified.json`、同名 `.jsonl` 与 `.patch`。
- 客户指标任务：`external/native-results/division-verified-01-verified.json`、同名 `.jsonl` 与 `.patch`。
- 外部适配与来源说明：[PUBLIC_BENCHMARK.md](PUBLIC_BENCHMARK.md)。

## v1 实际结果

| 任务 | 模式 | 步数上限／实际模型调用 | 原验收组件通过 | 任务 reward | 工具调用 | Tokens | 估算 USD |
|---|---|---:|---:|---:|---:|---:|---:|
| `dbt-fix-refund-reconciliation` | verified | 24／24 | 12／13 | 0 | 34 | 992,472 | 0.301547 |
| `dbt-fix-division-by-zero` | verified | 16／16 | 1／15 | 0 | 32 | 679,596 | 0.208002 |

任务通过 **0／2**。两题都因 `step_limit` 停止，没有最终自然语言交付。共 40 次模型调用、66 次工具调用、1,672,068 Tokens，按配置单价估算 0.509549 USD；实际账单以服务商为准。

组件部分通过用于定位失败，不折算成整题成功率。退款题少一个组件未通过，整题仍失败。

## 失败一：已写补丁，却在成功查询上停滞

退款题的关键事件按 `step` 可重现：

| 步骤 | 真实事件 | 说明 |
|---|---|---|
| 10 | `write_model`，修改 `rpt_return_reconciliation.sql` | 已产生实际代码变更 |
| 11 | `run_dbt(build, select=rpt_return_reconciliation)` 返回成功 | 构建成功 |
| 12 | 检查唯一行、NaN/Inf 与分层分布 | 查询均有正常结果 |
| 13 | `check_contracts` 返回 `passed=true, available=false, checks=[]` | 当前外部项目没有额外的 DataPatch 可见契约；不表示所有业务规则已验收 |
| 17–24 | 连续 8 次同一 SQL 查询 | 数据库未再修改，结果相同，直到预算耗尽 |

末尾重复查询的核心返回一直是：

```text
columns: n, non_null_rate, non_null_days, non_null_eff, over_refund
rows:    287, 287, 165, 165, 125
```

完整 24 步中有 3 次文件读取、28 次 SQL 查询、1 次模型写入、1 次 dbt 执行和 1 次可见契约检查。末尾重复并非查询失败后的重试；工具已成功返回，模型仍继续请求。

根据当前代码，assistant 工具调用后追加对应 `tool_call_id` 的结果，再请求下一轮模型；没有发现消息排序错误。日志也没有显示同一稳定状态下工具先报成功再报相反结果。因此，目前证据支持“缺少停滞反馈与交付推进机制”，不支持直接归因于工具协议冲突。

## 失败二：查询不断变长，但没有增加信息或交付补丁

客户指标题执行了 3 次文件读取、29 次 SQL 查询，**没有 `write_model`，也没有 `run_dbt`**。

前期模型试图区分订单状态、客户标识与时间字段中的空值。随后查询中的 `NOT IN (...)` 状态集合不断扩展，最后又重复追加已经存在的 `'CANCELLED','cancelled'`。SQL 字符串在变化，业务含义和结果却没有变化。

从第 11 步到预算结束，相同列与零结果共出现 12 次：

```text
columns: n, dcust, null_ts, mx
rows:    0, 0, null, null
```

这说明仅比较“工具名＋完整参数字符串”不足以发现停滞。同义 SQL 或冗余条件仍能绕过精确参数去重。最终验收只有编译组件通过，新增分析列与其他业务要求没有完成。

不能把这一题描述成“仅最后一个边界未修好”；它在预算内没有从数据探索进入代码交付。

## 一个独立的业务错误：CASE 没有改变窗口总体

退款补丁还包含下面的计算模式：

```sql
case
    when total_processing_days is not null
    then percent_rank() over (order by total_processing_days desc)
end
```

这只把 NULL 行的最终输出置空，没有在窗口计算前排除这些行。任务要求只在处理天数非 NULL 的记录中计算分位数；错误总体改变窗口分母，最终 `component_8_waterfall_tier_logic` 失败。

该错误来自结束后的验收分析。原失败补丁没有被手工改成成功记录。此例说明编译成功、列齐全、没有 NaN/Inf，与分层业务语义正确是不同检查。

停滞检测能够减少浪费或促成交付，但它本身不会保证窗口总体选对。业务语义仍需要通过任务约束、可见反例与最终独立验收检验。

## 上下文成本的实际证据

| 任务 | 首次请求输入 Tokens | 最后一次请求输入 Tokens |
|---|---:|---:|
| refund-reconciliation | 33,531 | 44,365 |
| division-by-zero | 34,504 | 46,276 |

v1 的结构化上下文会包含较广的 schema 与模型依赖信息，历史工具消息又随轮次增加。原始 usage 显示，两个案例在开始时就有较高的输入成本，重复请求进一步放大总量。

v2 已实现定向选择目标模型、上游依赖和相关表结构，并限制上下文字符预算。但两条轨迹不足以证明“上下文大”是循环的唯一原因；是否改善完成率和成本，需要新版本真实运行验证。

## 审阅发现的评分漏洞：旧表正确，最终 SQL 却不能构建

原来的 `RunService._execute()` 先执行最终 dbt build，再调用 `verify_task()`，但没有把 build 成功加入任务成功条件。若模型曾构建过正确表，随后提交了无效 SQL，失败的 dbt 执行可能保留旧物化结果。Oracle 读旧表仍能通过，而当时的统计会把整题计为成功。

这个问题已在无模型调用的临时任务中复现：

```text
先物化正确结果
→ 将最终 SQL 改成语法错误
→ final_build.success = false
→ 原 verify_task().passed = true（读取旧表）
→ 原 summarize() 将该记录计为成功
```

**已修复的评分规则：** 最终构建成功与 Oracle 通过取 AND；验收增加 `final_build_success` 检查，保留原 Oracle 的所有检查。构建失败的说明明确提示匹配数据可能来自旧表。运行流程完成仍记为 `completed`，任务成功单独由 `verification.passed` 表达。

`tests/test_service.py::test_final_score_requires_build_and_independent_output_checks` 用 FakeWorkspace/FakeAgent 覆盖“旧表正确但构建失败”和“构建及输出都正确”两种情况；两项回归均通过，无真实 API 调用。

审阅正式合成评测前 12 条已完成记录时，没有出现该假阳性条件。该观察只覆盖当时的 12 条；完整报告应按全部原始 `final_build` 证据统一复核。评分修订需要与策略源码版本分开记录，不能把它当作 Agent 策略提升。

## 已发生的执行故障：Windows 拒绝替换运行记录

合成评测中的 `refund_reconciliation_holdout / context` 有一条实际环境错误：

```text
Run ID: c8f7420b-86a5-48cc-8594-da441698f7fa
PermissionError / WinError 5
run.json.tmp → run.json
```

当时记录了 6 次模型调用、9 次工具调用和 17,647 Tokens，失败发生在结果持久化，而不是最终业务验收。可能原因是 Windows 的读者或安全软件短暂占用目标文件；单凭异常无法确定具体占用者。不同进程中的线程锁不能互相协调文件访问。

**已加入代码的修复：** `write_json()` 对真实观察到的 `PermissionError` 做有限次数退避重试，仅重试文件替换，不重新调用模型；持久化回归测试已通过。它降低短暂共享冲突导致任务中断的风险，但不追溯改变原次运行的实际失败。

原失败保留在总体统计与基础设施失败计数中。若另做重测，应作为新运行单独记录，不能静默删除或覆盖它。

## 状态清单：已解决什么，还没有证明什么

| 问题 | 当前证据 | 修订状态 |
|---|---|---|
| 最终构建失败仍可能得分 | 临时执行复现，原评分会读旧表通过 | 已修复评分 AND 规则，有无 API 回归测试；历史成绩需统一重算 |
| Windows JSON 替换失败 | 一条真实 `WinError 5` 运行 | 已加入有限文件操作重试；原失败保留 |
| 退款分层窗口总体错误 | 上游组件 8 失败与实际补丁 | v1 失败保留，不能因代码审阅而改记成功 |
| 精确／语义重复查询 | 退款 8 次同 SQL；客户指标 12 次同结果 | v2 已实现结果指纹第 3 次出现时的停滞反馈，实际效果待新版本重测 |
| 探索未推进到交付 | 客户指标全程未写模型 | v2 已实现读无写与剩余步数提醒，是否促成交付待重测 |
| 过宽上下文与输入成本 | 首次请求已超过 3 万输入 Tokens | v2 已实现定向上下文与字符预算，Token／效果收益待重测 |

## v2 已实现的通用改动，尚待独立重测

`agent.py` 将版本记为 `v2-focused-context-progress-reminders`，新增机制不按任务 ID 写答案：

- 对成功 `query_sql` 的 `columns / rows / truncated` 建结果指纹，忽略耗时。相同状态下同一观察第 3 次出现时，在工具反馈中加入停滞提示。模型写入或成功 dbt 执行后清空统计，保留有意义重验的机会。
- 连续 8 次读操作没有推进写入时提醒；剩余 4 次或 2 次模型调用时再次提示预算，要求实现补丁、执行定向验证，或明确说明阻塞。提示不会替模型填写业务计算。
- `context.py::build_task_context()` 从指令或显式焦点定位目标 SQL，附带有限上游依赖、相关 schema 与来源记录；`_finish()` 控制序列化字符数，目标未找到时给候选文件和进一步工具指引，避免直接注入全库。

已实现这些代码不等于已经证明任务通过率提高。新版合成 smoke 与两道公开开发题重测应分别保存实际运行和版本证据，由对应结果报告给出数字。

原 54 次合成对照使用 v1 已加载的策略继续执行，其冻结源码为 `artifacts/evaluations/synthetic_holdout_20261025_source.zip`。不要把这批成绩标成 v2；评分器的旧表漏洞修订也应单独记录，保留原始 build 与 Oracle 证据。

本页不报告 v2 成绩。基于上述两题反馈修改策略后再次运行，仍是公开开发题迭代；要声称泛化，需要额外冻结策略与未用于调试的任务集合。
