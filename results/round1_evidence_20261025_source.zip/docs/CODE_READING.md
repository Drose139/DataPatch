# DataPatch：投递前读懂与修改清单

本项目面向数据工程工单：模型查看 dbt 项目与数据库，修改 SQL，再由真实执行和独立业务验收判断结果。快速接手时，先沿着一次实际运行读下面 9 处代码，再完成一项能够解释的修改。无需先把整个 Agent 生态学完。

## 先打开一份实际运行记录

工作台的「运行记录 → 运行数据」对应 `artifacts/runs/<run_id>/run.json`。从中选出 `task_id`、`mode`、一次工具调用、代码 Diff 和最终 `verification`，在代码里逐项找到产生它们的位置。

`status="completed"` 仅代表流程完成；任务是否修好看 `verification.passed`。测试替身生成的记录只能用于测试，不能算成真实模型结果。

## 必须看懂的 9 处

| 代码位置 | 具体看什么 | 能解释到什么程度 |
|---|---|---|
| `src/datapatch/agent.py`：`Agent.run()`、`_response()`、`_single_patch()` | 模型消息、Tool Calling、工具返回、步数与估算费用限制；4 种模式的开关；v2 重复观察与进度提醒 | 说清一次工具调用如何返回模型；指出交付门控、相同查询结果第 3 次出现的提示，以及剩余 4／2 次调用时的预算提醒 |
| `src/datapatch/context.py`：`build_task_context()`、`_schema()`、`_finish()` | 从指令或 `focus_model` 定位目标 SQL；有界上游依赖与相关 schema；24,000 字符预算及来源元数据 | 解释为何目标上下文优于直接塞全库；未找到目标时怎样退回候选文件与工具指引；字符预算不是 Token 上限；选择不读取参考答案或隐藏验收 |
| `src/datapatch/workspace.py`：`call()`、`tool_definitions()`、`write_model()`、`query_sql()` | 工具注册；只允许修改 `models/` 下 SQL；只读 SELECT；输出截断 | 添加工具必须同时改注册和 schema；知道这些是应用层约束，当前本机执行不是 OS 沙盒 |
| `src/datapatch/workspace.py`：`search_schema()`、`get_lineage()`、`check_contracts()` | 表结构与 `ref()` 依赖；返回违规行的可见 SQL 契约 | 血缘来自解析 SQL 中的 dbt `ref()`，不是完整 SQL 语义分析器；可见检查通过仍可能业务错误 |
| `src/datapatch/fixtures.py`：`_SPECS`、`_data()`、`create_task()` | 6 类问题、dev/holdout 数据、任务工作区的实际文件 | 当前是 6 类语义 × 2 个数据变体，共 12 个自建任务；holdout 改数据，没有引入未知问题类型 |
| `src/datapatch/fixtures.py`：`_oracle()`、`verify_task()`、`_replay_incremental()` | 独立 Python 计算、所有行的值比较、源数据完整性、增量重复执行 | Oracle 与参考修复不会复制到模型的任务目录；最终验收不反馈 Agent；增量任务不能只靠第一次运行的正确结果判断 |
| `src/datapatch/service.py`：`_new()`、`_execute()`、内部 `emit()`、`write_json()` | 初始化任务 → dbt seed/run → Agent → 最终 build → 独立验收 → 保存产物 | 成功必须同时满足最终构建与 Oracle；指出防止旧表假阳性的检查，以及 Windows 文件替换的有限重试；持久化支持审阅与回放，未实现进程重启续跑 |
| `src/datapatch/evaluation.py`：`evaluate()`、`summarize()` | 先冻结协议、统一任务与步数、每次真实运行保留、按模式统计 | 指出失败仍在分母；区别单次通过率、每题多次全部成功率；知道结果含估算成本与 Wilson 区间，小样本不能轻率声称显著提升 |
| `src/datapatch/provider.py`：`DeepSeekClient.complete()` | 实际 API 请求、usage、延迟、有限重试、异常脱敏 | 知道传了哪些参数、如何取工具调用；Token 来自响应，美元费用来自配置单价估算，并非账单实付 |

前端位于 `src/datapatch/static/`，`src/datapatch/web.py` 负责调用服务接口。面试核心讨论应围绕上表的执行与验收链路。

阅读旧运行时同时看 `agent_revision` 与报告代码版本。v1 原始策略和 v2 定向上下文／进度反馈分开保存，不能用 v2 的代码解释成 v1 当时已经具备这些机制。[FAILURE_ANALYSIS.md](FAILURE_ANALYSIS.md) 记录了触发这次修订的两道真实外部失败。

## 两项值得亲手完成的改动

以下是建议，仓库初版并未声称已经完成这些扩展。选择一项做实并留下 Diff、执行记录和解释即可；完成两项则能分别展示业务判断与评测判断。

### 改动 A：补一条退款比例的语义契约

当前 `_visible_checks()` 中，退款检查重点是记录覆盖与比例有限性。可以增加 `refund_ratio_semantics`：正数申请金额时，比例必须等于 `paid_cents / requested_cents`；零申请金额时必须为 `0.0`。

具体修改：

1. 在 `src/datapatch/fixtures.py::_visible_checks()` 的退款分支增加一条 SQL，返回违反上述关系的记录；浮点比较采用明确容差。
2. 在 `tests/test_fixtures.py` 中增加反例：令输出比例恒为 `0.0`。它虽然是有限数，但对正数已付款退款不正确，新契约应报出违规行。
3. 对同一任务、同一模型、同一模式重新运行，比较旧版和新版轨迹；检查是否因更早得到反馈而改变工具调用或最终结果。保留失败结果，不能预先断言指标提升。

独立 Oracle 保持不变。可见契约增加的是业务规则反馈，最终验收仍然比较所有输出行。

适合解释的决策：为什么「不是 NaN/Inf」仍不足以保证业务计算正确；为什么把有意义的失败反馈交给 Agent，而不是只给一个布尔值。

### 改动 B：增加“退款超过收入”的独立数据变体

当前 LTV 任务定义 `net_cents = gross_cents - refund_cents`。加入一个退款总额超过商品收入的人，可以检查 Agent 是否擅自把负数截断成零，或把“净收入必须非负”当成不存在的规则。

具体修改：

1. 在 `fixtures.py` 中新增明确命名的 stress 数据变体，保留已有 dev/holdout 数据与随机种子；让至少一位已完成订单客户的累计实付退款超过商品收入。
2. 让任务生成器能够选中这个新变体；相同业务契约下，Python Oracle 应自然得到负净收入，无需把期望值写进任务目录。
3. 补一个测试，确认正确 SQL 的负净收入通过验收、`greatest(net_cents, 0)` 形式的错误修复被验收拒绝。同步更新目录数量断言。
4. 为新增变体单独生成评测报告，记录新的数据版本和代码摘要；旧报告的分母与任务集合保持原样。

适合解释的决策：规则从业务契约来，不能从“常识”猜；数据变体应挑战错误假设，而不只是多生成几行。

## 修改后保留的最小证据

- 一份能指向具体函数的代码 Diff。
- 一次修改前后的真实运行，或一个清楚标记为测试的执行级反例。
- 一段实际失败原因与边界说明；若结果没有提升，也如实解释。

投递时只描述自己实际审阅、修改与验证过的部分。初版可以明确说明由 AI 辅助搭建；可讲清楚的技术取舍和真实验证是项目的主要价值。
