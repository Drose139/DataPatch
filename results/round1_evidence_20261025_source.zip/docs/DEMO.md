# DataPatch：3 分钟演示

演示使用真实模型执行，或明确说明是在回放已保存的真实模型记录。已记录回放展示原始数据，不重演或伪造模型输出。

## 启动与准备

在项目根目录、已安装项目依赖的 Python 环境中执行：

```powershell
python -m datapatch.cli doctor
python -m datapatch.cli serve
```

打开 [http://127.0.0.1:8000](http://127.0.0.1:8000)。Windows 终端未激活虚拟环境时，直接使用 `.\.venv\Scripts\python.exe -m datapatch.cli serve`。

`doctor` 只检查配置，不发起模型请求。模型 API 密钥在项目根目录 `.env` 配置，浏览器不需要填写密钥。当前后端为可信项目的本机执行，没有 Docker 隔离演示。

建议先完成一个 `revenue_fanout_dev` 的 `verified` 真实运行，确认模型可访问、任务可执行，并找到实际保存的 Run ID。命令行方式：

```powershell
python -m datapatch.cli run revenue_fanout_dev --mode verified --max-steps 16
```

原始产物位置：

```text
artifacts/runs/<run_id>/run.json
artifacts/runs/<run_id>/events.jsonl
artifacts/runs/<run_id>/patch.diff
artifacts/runs/<run_id>/verification.json
```

演示前查看该记录的 `provider`、`model`、`status` 和 `verification`。选择已完成、自己能解释的真实记录。它可以失败；失败案例也能展示验证如何发现问题。不要把单元测试里的 FakeClient 结果当成模型运行。

## 推荐：3 分钟真实历史回放

真实在线运行耗时取决于模型响应、工具步骤与 dbt 执行，不能保证在 3 分钟内结束。面试演示优先采用已完成记录，先说明回放来源；另准备现场启动入口，供对方验证。

| 时间 | 屏幕操作 | 讲解要点 |
|---|---|---|
| 0:00–0:20 | 显示工作台；打开「运行记录」 | “这是已保存的真实 DeepSeek 运行回放，页面读取原始事件；接下来不重新生成模型回答。”指出 Run ID、模型和模式 |
| 0:20–0:45 | 打开 `revenue_fanout_dev` 记录；展开任务上下文 | 一单多条明细、一单多次支付，直接关联会放大金额。需要保证一单一行并分别对账；数据为合成零售场景 |
| 0:45–1:20 | 在执行轨迹中展开一次读取／查询，再展开一次写入或 dbt 执行 | 展示实际工具参数与真实返回。说明模型怎样从证据决定修改；以记录为准，不预设它必须采用哪一种修复 |
| 1:20–1:50 | 切到「代码变更」 | 指出补丁里的关键 SQL。正确方向通常是先在订单粒度聚合各个一对多来源，再关联；具体是否正确由验收结果判断 |
| 1:50–2:20 | 切到「业务检查」与「运行数据」 | 展示列、行数、所有行值、源数据完整性检查。说明运行完成与验证通过分开；最终 Oracle 结果没有用于修复反馈 |
| 2:20–2:45 | 打开「对比评测」中的一份真实报告 | 指出模型、任务集和样本数；比较 `react/context/verified` 的实际结果、Token 与耗时。只讲文件里存在的数据 |
| 2:45–3:00 | 回到补丁或自己改动过的契约 | 一句话介绍个人实际修改和一个边界：自建任务、同类型数据 holdout、本机可信执行；下一步根据失败记录改进 |

如果该记录没有模型修复重试，就不要声称这次展示了自动恢复。可另找真实出现“检查失败 → 继续修改 → 再验证”的记录；没有这样的记录时，说明代码具备反馈路径，是否改善效果还需实验。

## 现场真实启动方式

1. 左侧选任务；选择 `verified`，确认最大步数与模型配置。
2. 点击「启动修复」。每秒更新的轨迹来自服务端真实执行；运行中不要重复点击启动。
3. 展开工具事件看参数与返回，查看耗时与 Token。执行结束后先看业务验收，再看模型的交付文字。
4. 若超出演示时间，保留该运行并切到已有真实记录，明确说明切换。API 或执行失败时直接展示错误原因与已保存记录。

## 生成一份可演示的评测报告

以下命令使用三个机制条件，对固定 holdout 任务进行实际模型评测，会产生真实 API 费用：

```powershell
python -m datapatch.cli eval --modes react context verified --repeats 1 --workers 2 --max-steps 16 --name holdout_comparison
```

结果写入：

```text
artifacts/evaluations/holdout_comparison.json
artifacts/evaluations/holdout_comparison.md
```

报告 JSON 的 `protocol` 保存任务 ID、模型、预算与代码摘要；`records` 保留逐次执行，`summary` 是汇总。若费用预算使评测提前停止，报告会显示相应状态，不能按全部计划任务已完成来介绍。

只做一次运行不能证明重复稳定性。若需要讨论这个指标，实际执行多次重复并查看报告中的每题全部成功率；没有重复实验时，直接说明没有测。

演示结束时，提供仓库、这份运行的 Run ID 和所引用报告文件，方便面试官沿原始证据复核。

## 已验收的真实回放截图

以下截图读取本地真实模型运行 `1dccea01-364d-4d87-9a77-ab6ed5449d85`，任务为 `revenue_fanout_dev`，模式为 `verified`。页面保留“已记录真实运行回放”标签。截图展示的是这一条运行，不能当作整体评测结果。

- [执行轨迹与独立检查](screenshots/workbench.png)
- [实际模型补丁](screenshots/workbench-diff.png)
