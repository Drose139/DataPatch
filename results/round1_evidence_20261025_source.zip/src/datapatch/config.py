"""Configuration stays on the server; no credentials are returned to the UI."""
from __future__ import annotations

import os
from dataclasses import dataclass
from pathlib import Path

from dotenv import load_dotenv

ROOT = Path(__file__).resolve().parents[2]


@dataclass
class Settings:
    api_key: str = ""
    base_url: str = "https://api.deepseek.com"
    model: str = "deepseek-flash"
    max_steps: int = 18
    max_output_tokens: int = 3000
    request_timeout: float = 120
    input_rate: float = 0.30
    output_rate: float = 1.20
    run_budget_usd: float = 0.50
    eval_budget_usd: float = 3.00
    artifacts_dir: Path = ROOT / "artifacts"

    @classmethod
    def load(cls) -> "Settings":
        load_dotenv(ROOT / ".env", override=False)
        return cls(
            api_key=os.getenv("DEEPSEEK_API_KEY", ""),
            base_url=os.getenv("DEEPSEEK_BASE_URL", "https://api.deepseek.com").rstrip("/"),
            model=os.getenv("DEEPSEEK_MODEL", "deepseek-flash"),
            max_steps=int(os.getenv("DATAPATCH_MAX_STEPS", "18")),
            max_output_tokens=int(os.getenv("DATAPATCH_MAX_OUTPUT_TOKENS", "3000")),
            request_timeout=float(os.getenv("DATAPATCH_REQUEST_TIMEOUT", "120")),
            input_rate=float(os.getenv("DATAPATCH_INPUT_USD_PER_MILLION", "0.30")),
            output_rate=float(os.getenv("DATAPATCH_OUTPUT_USD_PER_MILLION", "1.20")),
            run_budget_usd=float(os.getenv("DATAPATCH_RUN_BUDGET_USD", "0.50")),
            eval_budget_usd=float(os.getenv("DATAPATCH_EVAL_BUDGET_USD", "3.00")),
            artifacts_dir=Path(os.getenv("DATAPATCH_ARTIFACTS", str(ROOT / "artifacts"))),
        )

