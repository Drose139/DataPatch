"""A requirements-based second pass over a candidate, with no grading access.

The reviewer uses the same configured model and the same total call budget.
Its opinion is visible feedback, never a replacement for execution or grading.
"""
from __future__ import annotations

import json
from typing import Callable


REVIEW_PROMPT = """You review a candidate dbt SQL patch against a public engineering ticket.
The original SQL can contain bugs. Preserve behavior the ticket does not authorize changing.
First extract the requested changes and preserved business rules from the ticket and project README.
Then compare the original SQL and actual patch. Check joins, filters, grouping, numeric and NULL
semantics against those rules. Do not assume normalization, new exclusions, or convenient defaults
are authorized. A successful build, unchanged row count or an empty test list is not semantic proof.
Report only concrete, evidenced concerns with file/SQL expressions and an actionable validation.
Do not invent expected values, hidden tests, or a reference solution. If evidence is insufficient,
say so. You cannot execute tools in this review pass; the executor can investigate your findings.
Return ONLY JSON: {"verdict":"approve|revise|inconclusive", "summary":"...",
"findings":[{"concern":"...","evidence":"...","validation":"..."}]}.
Use at most 5 findings. An approve verdict is an advisory opinion, not task success.
"""


def review_candidate(workspace, instruction: str, task_context: dict, respond: Callable) -> dict:
    patch = workspace.diff()
    # Only changed files, original code, and visible task context. Never inspect
    # final verification, reference solutions, hidden tests, or prior runs.
    originals = {}
    for path, content in getattr(workspace, "original", {}).items():
        if f"--- a/{path}" in patch:
            originals[path] = content
    context = {
        "ticket": instruction,
        "visible_task_context": task_context,
        "original_changed_models": originals,
        "candidate_patch": patch,
    }
    encoded = json.dumps(context, ensure_ascii=False, default=str)
    # This is a character bound, not an exact tokenizer-based token limit.
    truncated = len(encoded) > 42000
    if truncated:
        context = {"ticket": instruction[:10000], "candidate_patch": patch[:18000],
                   "original_changed_models": {p: c[:8000] for p, c in list(originals.items())[:1]},
                   "context_truncated": True}
    response = respond([
        {"role": "system", "content": REVIEW_PROMPT},
        {"role": "user", "content": json.dumps(context, ensure_ascii=False, default=str)},
    ], None)
    raw = response["message"].get("content") or ""
    cleaned = raw.strip()
    if cleaned.startswith("```") and "\n" in cleaned:
        cleaned = cleaned.split("\n", 1)[1].rsplit("```", 1)[0]
    try:
        parsed = json.loads(cleaned)
        if not isinstance(parsed, dict) or parsed.get("verdict") not in {"approve", "revise", "inconclusive"}:
            raise ValueError("Review verdict is invalid")
        findings = parsed.get("findings", [])
        if not isinstance(findings, list) or not all(isinstance(x, dict) for x in findings):
            raise ValueError("Review findings are invalid")
        verdict = parsed["verdict"]
        if verdict == "revise" and not findings:
            verdict = "inconclusive"
        result = {"verdict": verdict, "summary": str(parsed.get("summary", ""))[:2000],
                  "findings": [{str(k): str(v)[:2000] for k, v in row.items() if k in {"concern", "evidence", "validation"}} for row in findings[:5]]}
    except (ValueError, TypeError):
        result = {"verdict": "inconclusive", "summary": "Review returned invalid structured output; no approval inferred.", "findings": [], "raw_response": raw[:3000]}
    return {**result, "context_truncated": truncated, "advisory_only": True, "hidden_feedback_used": False}
