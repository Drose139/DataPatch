"""Small OpenAI-compatible HTTP adapter, with recorded usage and bounded retries."""
from __future__ import annotations

import time
from typing import Any

import httpx

from .config import Settings


class ModelError(RuntimeError):
    pass


class DeepSeekClient:
    def __init__(self, settings: Settings):
        if not settings.api_key:
            raise ModelError("尚未配置 DEEPSEEK_API_KEY。请填写项目根目录的 .env。")
        self.settings = settings

    def complete(self, messages: list[dict], tools: list[dict] | None = None) -> dict[str, Any]:
        s = self.settings
        body: dict[str, Any] = {
            "model": s.model,
            "messages": messages,
            "temperature": 0,
            "max_tokens": s.max_output_tokens,
            "thinking": {"type": "disabled"},
        }
        if tools:
            body["tools"] = tools
        started = time.monotonic()
        with httpx.Client(timeout=s.request_timeout) as client:
            for attempt in range(3):
                try:
                    response = client.post(
                        f"{s.base_url}/chat/completions",
                        headers={"Authorization": f"Bearer {s.api_key}"},
                        json=body,
                    )
                except (httpx.TimeoutException, httpx.NetworkError) as exc:
                    if attempt == 2:
                        raise ModelError(f"模型网络请求失败：{type(exc).__name__}") from None
                    time.sleep(2 ** attempt)
                    continue
                if response.status_code in (429, 500, 502, 503, 504) and attempt < 2:
                    time.sleep(2 ** attempt)
                    continue
                if response.is_error:
                    # Do not echo request headers, URLs with credentials, or the key.
                    detail = response.text[:500].replace(s.api_key, "[REDACTED]")
                    raise ModelError(f"模型 API HTTP {response.status_code}: {detail}")
                data = response.json()
                if not data.get("choices"):
                    raise ModelError("模型 API 未返回 choices")
                usage = data.get("usage", {})
                prompt = int(usage.get("prompt_tokens", 0))
                completion = int(usage.get("completion_tokens", 0))
                return {
                    "message": data["choices"][0]["message"],
                    "finish_reason": data["choices"][0].get("finish_reason"),
                    "model": data.get("model", s.model),
                    "response_id": data.get("id"),
                    "usage": usage,
                    "estimated_cost_usd": (prompt * s.input_rate + completion * s.output_rate) / 1_000_000,
                    "latency_seconds": round(time.monotonic() - started, 3),
                }
        raise ModelError("模型请求未完成")
