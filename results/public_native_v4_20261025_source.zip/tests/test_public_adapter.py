from __future__ import annotations

import importlib.util
import io
import json
from pathlib import Path

import pytest


def module_from_path(name: str, path: str):
    spec = importlib.util.spec_from_file_location(name, Path(__file__).parents[1] / path)
    module = importlib.util.module_from_spec(spec)
    assert spec.loader is not None
    spec.loader.exec_module(module)
    return module


fetch = module_from_path("benchmark_fetch", "scripts/fetch_public_benchmark.py")
adapter = module_from_path("benchmark_adapter", "integrations/harbor_agent.py")


def test_fetch_allowlist_excludes_answers_and_other_tasks():
    tasks = ("dbt-fix-refund-reconciliation",)
    assert fetch.selected_path("base-image/dbt_models_duckdb/tests/generic/test_not_null.sql", tasks)
    assert fetch.selected_path("tasks/dbt-fix-refund-reconciliation/environment/data/rpt_return_reconciliation.sql", tasks)
    for path in (
        "tasks/dbt-fix-refund-reconciliation/solution/solve.sh",
        "tasks/dbt-fix-refund-reconciliation/tests/test_outputs.py",
        "tasks/another-task/instruction.md",
        "base-image/dbt_models_duckdb/../../solution/solve.sh",
    ):
        assert not fetch.selected_path(path, tasks)


@pytest.mark.parametrize("task_id", ["dbt-fix-refund-reconciliation", "dbt-fix-inventory-model"])
def test_prepare_overlays_bug_without_copying_private_material(tmp_path, task_id):
    snapshot = tmp_path / "snapshot"
    target = adapter.PUBLIC_TASK_MODELS[task_id]
    original = snapshot / "base-image/dbt_models_duckdb" / target
    original.parent.mkdir(parents=True)
    original.write_text("select 'base' as state", encoding="utf-8")
    (snapshot / "base-image/database").mkdir()
    (snapshot / "base-image/database/retail.duckdb").write_bytes(b"test-database")
    task = snapshot / "tasks" / task_id
    (task / "environment/data").mkdir(parents=True)
    (task / "environment/data" / Path(target).name).write_text("select 'bug' as state", encoding="utf-8")
    (task / "instruction.md").write_text("Edit /app/dbt_models_duckdb/" + target, encoding="utf-8")
    (task / "solution").mkdir()
    (task / "solution/solve.sh").write_text("secret-reference", encoding="utf-8")
    (snapshot / "snapshot-lock.json").write_text(json.dumps({"commit": adapter.PINNED_COMMIT, "tasks": [task_id], "database": {"bytes": 13}}), encoding="utf-8")
    case = tmp_path / "case"
    metadata = adapter.prepare_native_case(snapshot, case, task_id, initialize=False)
    assert metadata["official_harbor_result"] is False
    assert (case / "project" / target).read_text(encoding="utf-8") == "select 'bug' as state"
    assert not list(case.rglob("solve.sh"))
    assert "/app/dbt_models_duckdb" not in (case / "instruction.md").read_text(encoding="utf-8")
    with pytest.raises(ValueError, match="empty"):
        adapter.prepare_native_case(snapshot, case, task_id, initialize=False)


def test_new_model_task_initializes_declared_inputs_without_creating_answer(tmp_path, monkeypatch):
    snapshot = tmp_path / "snapshot"
    task_id = "dbt-fix-product-metrics"
    project = snapshot / "base-image/dbt_models_duckdb"
    (project / "models/staging").mkdir(parents=True)
    for name in adapter.CREATE_MODEL_ANCESTORS[task_id]:
        (project / "models/staging" / (name + ".sql")).write_text("select 1 as id", encoding="utf-8")
    (snapshot / "base-image/database").mkdir()
    (snapshot / "base-image/database/retail.duckdb").write_bytes(b"test-database")
    task = snapshot / "tasks" / task_id
    task.mkdir(parents=True)
    (task / "instruction.md").write_text("Create models/marts/product/fct_product_metrics.sql", encoding="utf-8")
    (snapshot / "snapshot-lock.json").write_text(json.dumps({"commit": adapter.PINNED_COMMIT, "tasks": [task_id], "database": {"bytes": 13}}), encoding="utf-8")
    commands = []
    monkeypatch.setattr(adapter, "run_recorded", lambda command, **kwargs: commands.append(command))
    monkeypatch.setattr(adapter, "dbt_executable", lambda: "dbt")
    case = tmp_path / "case"
    meta = adapter.prepare_native_case(snapshot, case, task_id)
    assert meta["task_type"] == "create-model" and meta["initialized"]
    assert not (case / "project" / adapter.PUBLIC_TASK_MODELS[task_id]).exists()
    assert commands[-1][commands[-1].index("--select") + 1:] == ["+" + name for name in adapter.CREATE_MODEL_ANCESTORS[task_id]]


def test_fetch_rejects_empty_duplicate_or_unknown_subset_before_network(tmp_path):
    for tasks in ((), (fetch.DEFAULT_TASKS[0],) * 2, ("unknown-task",)):
        with pytest.raises(ValueError, match="subset"):
            fetch.fetch_snapshot(tmp_path, tasks)
    assert set(fetch.SUPPORTED_TASKS) == set(adapter.PUBLIC_TASK_MODELS)
    assert fetch.DEFAULT_TASKS == adapter.LEGACY_TASKS


def test_final_verifier_must_live_outside_agent_case(tmp_path):
    case = tmp_path / "case"
    case.mkdir()
    with pytest.raises(ValueError, match="outside"):
        adapter.evaluate_native_case(case, case / "hidden-tests")


def test_evaluator_really_invokes_pytest_and_preserves_binary_failure(tmp_path, monkeypatch):
    case = tmp_path / "case"
    case.mkdir()
    (case / "native-case.json").write_text(json.dumps({"task_id": "dbt-fix-refund-reconciliation", "upstream_commit": adapter.PINNED_COMMIT}), encoding="utf-8")
    # Like upstream, importing/running this module directly executes no test.
    source = b'''from pathlib import Path
def test_solution():
    print("PASS: component_1_model_compiles")
    print("FAIL: component_2_business_rule: counterexample")
    output = Path("/logs/verifier")
    output.mkdir(parents=True, exist_ok=True)
    (output / "reward.json").write_text('{"reward": 0.0}')
    assert False, "binary task failed despite a passing component"
'''
    monkeypatch.setattr(adapter.urllib.request, "urlopen", lambda *a, **k: io.BytesIO(source))
    result = adapter.evaluate_native_case(case, tmp_path / "evaluators")
    assert result["returncode"] == 1
    assert result["reward"] == 0.0
    assert result["components_passed"] == result["components_failed"] == 1


def native_summary_inputs(tmp_path, task_id, case_name):
    case = tmp_path / case_name
    case.mkdir()
    (case / "native-case.json").write_text(json.dumps({"task_id": task_id, "base_build": "selected inputs", "runtime": {"platform": "test"}}), encoding="utf-8")
    results = tmp_path / "agents"
    results.mkdir(exist_ok=True)
    (results / f"{case_name}-verified.json").write_text(json.dumps({"model": "example-model", "max_steps": 24, "budget_usd": 0.6,
        "generation_settings": {"thinking_enabled": True, "reasoning_effort": "high", "max_output_tokens": 16384},
        "observed_model_versions": ["example-model-version"],
        "result": {"stop_reason": "model_finished", "metrics": {"prompt_tokens": 10, "completion_tokens": 5, "total_tokens": 15}}}), encoding="utf-8")
    evaluators = tmp_path / "evaluators"
    directory = evaluators / task_id
    directory.mkdir(parents=True, exist_ok=True)
    verifier = {"returncode": 0, "reward": 1.0, "components_passed": ["component_1_model_compiles"], "components_failed": [],
                "stdout": "PASS: component_1_model_compiles\n1 passed in 0.10s\n"}
    (directory / f"{case_name}-evaluation.json").write_text(json.dumps(verifier), encoding="utf-8")
    return case, results, evaluators


def test_expanded_adapter_keeps_default_historical_report_at_two_tasks(tmp_path):
    output = tmp_path / "report.json"
    for i, task in enumerate(adapter.LEGACY_TASKS):
        adapter.render_public_summary(*native_summary_inputs(tmp_path, task, f"case-{i}"), output)
    report = json.loads(output.read_text(encoding="utf-8"))
    assert report["planned_trials"] == 2 and report["status"] == "completed"
    assert report["protocol"]["planned_task_ids"] == list(adapter.LEGACY_TASKS)
    assert report["records"][0]["observed_model_versions"] == ["example-model-version"]


def test_new_tasks_require_explicit_plan_and_plan_cannot_expand_later(tmp_path):
    task = "dbt-fix-inventory-model"
    inputs = native_summary_inputs(tmp_path, task, "inventory")
    output = tmp_path / "report.json"
    with pytest.raises(ValueError, match="outside"):
        adapter.render_public_summary(*inputs, output)
    adapter.render_public_summary(*inputs, output, planned_tasks=tuple(adapter.PUBLIC_TASK_MODELS))
    report = json.loads(output.read_text(encoding="utf-8"))
    assert report["planned_trials"] == 4 and report["status"] == "running"
    with pytest.raises(ValueError, match="frozen"):
        adapter.render_public_summary(*inputs, output, planned_tasks=(task,))


def test_repeat_protocol_requires_distinct_numbers_and_completes_full_matrix(tmp_path):
    task = "dbt-fix-inventory-model"
    first = native_summary_inputs(tmp_path, task, "first")
    second = native_summary_inputs(tmp_path, task, "second")
    output = tmp_path / "repeat.json"
    adapter.render_public_summary(*first, output, planned_tasks=(task,), repeat=0, repeats=2)
    with pytest.raises(ValueError, match="Duplicate"):
        adapter.render_public_summary(*second, output, repeat=0)
    adapter.render_public_summary(*second, output, repeat=1)
    report = json.loads(output.read_text(encoding="utf-8"))
    assert report["status"] == "completed" and report["planned_trials"] == 2
    assert [row["repeat"] for row in report["records"]] == [0, 1]


def test_zero_exit_without_actual_pytest_summary_is_not_task_pass(tmp_path):
    inputs = native_summary_inputs(tmp_path, adapter.LEGACY_TASKS[0], "not-executed")
    verifier_path = inputs[2] / adapter.LEGACY_TASKS[0] / "not-executed-evaluation.json"
    verifier = json.loads(verifier_path.read_text(encoding="utf-8"))
    verifier["stdout"] = "PASS: component_1_model_compiles\n"
    verifier_path.write_text(json.dumps(verifier), encoding="utf-8")
    output = tmp_path / "report.json"
    adapter.render_public_summary(*inputs, output)
    row = json.loads(output.read_text(encoding="utf-8"))["records"][0]
    assert row["verification"]["passed"] is False and row["status"] == "failed"


def test_actual_final_build_overrides_legacy_component_inference(tmp_path):
    inputs = native_summary_inputs(tmp_path, adapter.LEGACY_TASKS[0], "failed-build")
    path = inputs[1] / "failed-build-verified.json"
    agent = json.loads(path.read_text(encoding="utf-8"))
    agent["final_build"] = {"success": False, "stdout": "dbt build failed"}
    path.write_text(json.dumps(agent), encoding="utf-8")
    output = tmp_path / "report.json"
    adapter.render_public_summary(*inputs, output)
    row = json.loads(output.read_text(encoding="utf-8"))["records"][0]
    assert row["final_build"] == agent["final_build"]
    assert row["verification"]["passed"] is False
