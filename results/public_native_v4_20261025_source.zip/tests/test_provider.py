"""Provider contract tests use only an in-process HTTP transport."""
import json

import httpx
import pytest

from datapatch.config import Settings
from datapatch.provider import DeepSeekClient
import datapatch.provider as provider_module


@pytest.fixture
def mock_api(monkeypatch):
    requests = []
    payload = {
        "id": "mock-response",
        "model": "deepseek-v4-pro",
        "choices": [{
            "finish_reason": "stop",
            "message": {
                "role": "assistant",
                "content": "Mock handoff",
                "reasoning_content": "Synthetic test reasoning",
            },
        }],
        "usage": {
            "prompt_tokens": 100,
            "completion_tokens": 200,
            "total_tokens": 300,
            "completion_tokens_details": {"reasoning_tokens": 150},
        },
    }

    def handle(request):
        assert request.method == "POST"
        assert request.url == httpx.URL("https://provider.test/chat/completions")
        requests.append(json.loads(request.content))
        return httpx.Response(200, json=payload)

    original_client = httpx.Client
    transport = httpx.MockTransport(handle)
    monkeypatch.setattr(
        provider_module.httpx,
        "Client",
        lambda **kwargs: original_client(transport=transport, **kwargs),
    )
    return requests, payload


@pytest.mark.parametrize("effort,output_limit", [("high", 16384), ("max", 32768)])
def test_thinking_request_preserves_effort_and_output_budget(mock_api, effort, output_limit):
    requests, _ = mock_api
    settings = Settings(
        api_key="unit-test-key",
        base_url="https://provider.test",
        model="deepseek-v4-pro",
        thinking_enabled=True,
        reasoning_effort=effort,
        max_output_tokens=output_limit,
    )
    tools = [{"type": "function", "function": {"name": "query_sql", "parameters": {"type": "object"}}}]
    messages = [{"role": "user", "content": "Inspect the report"}]

    DeepSeekClient(settings).complete(messages, tools)

    assert len(requests) == 1
    request = requests[0]
    assert request["model"] == "deepseek-v4-pro"
    assert request["thinking"] == {"type": "enabled"}
    assert request["reasoning_effort"] == effort
    assert request["max_tokens"] == output_limit
    assert "temperature" not in request
    assert request["messages"] == messages
    assert request["tools"] == tools


def test_nonthinking_flash_keeps_legacy_request_compatibility(mock_api):
    requests, _ = mock_api
    settings = Settings(
        api_key="unit-test-key",
        base_url="https://provider.test",
        model="deepseek-flash",
        thinking_enabled=False,
        max_output_tokens=3000,
        input_rate=0.30,
        output_rate=1.20,
    )

    DeepSeekClient(settings).complete([{"role": "user", "content": "Repair SQL"}])

    assert len(requests) == 1
    request = requests[0]
    assert request["model"] == "deepseek-flash"
    assert request["thinking"] == {"type": "disabled"}
    assert request["max_tokens"] == 3000
    assert request["temperature"] == 0
    assert "reasoning_effort" not in request
    assert "tools" not in request


def test_reasoning_usage_is_preserved_without_double_counting_output_cost(mock_api):
    _, payload = mock_api
    payload["choices"][0]["finish_reason"] = "length"
    settings = Settings(
        api_key="unit-test-key",
        base_url="https://provider.test",
        input_rate=1.32,
        output_rate=3.96,
    )

    response = DeepSeekClient(settings).complete([{"role": "user", "content": "Repair SQL"}])

    # The API's 200 completion tokens already include the 150 reasoning tokens.
    assert response["usage"] == payload["usage"]
    assert response["estimated_cost_usd"] == pytest.approx((100 * 1.32 + 200 * 3.96) / 1_000_000)
    assert response["finish_reason"] == "length"
    assert response["message"]["reasoning_content"] == "Synthetic test reasoning"
    assert response["response_id"] == "mock-response"
