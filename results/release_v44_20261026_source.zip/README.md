# DataPatch

面向数据工程工单的代码修复与验证 Agent。给它一个 dbt/DuckDB 项目和工单，它读取代码、探查数据、修改模型、运行检查，输出可审阅的补丁、执行轨迹和独立验收结果。

**项目提供真实 DeepSeek 调用、12 个可复现合成任务、4 种实验配置、中文工作台和 8 个固定公开任务适配。** 修复交付包含 SQL 补丁、业务检查与运行记录；合成任务记录前后数据变化，公开记录未保存快照时明确显示缺失。

第一版验收后已对照十余个相关开源项目，按数据证据、语义复核、离线结果审计分三轮改进。[调研与迭代验收](docs/IMPROVEMENTS.md)记录采用理由与实际结果；[完整评测](docs/RESULTS.md)保留所有失败。

## 公开工程扩展结果

已支持 Snowflake `data-eng-bench` 八个固定公开任务。成品补丁覆盖退款、客户、库存、商品、时区、日报、结算汇率和留存；以下结果分别保留：

| 记录 | 已完成结果 | 来源 |
|---|---|---|
| v4.1 历史 Flash 两轮 | 首轮 **3/4**；第二轮仅商品 **8/11，整题失败** | 55 次调用，保守估算 $0.397302；退款、客户、库存分别 13/13、15/15、12/12 |
| 已审阅成品补丁 | **8 个不同公开任务最终通过**，9 次验收尝试保留 1 次依赖下载失败 | `operator_reviewed`，全新原始工程复验，零模型 API；原四题严格 build，新四题按原物化/pytest 协议及显式 UTC；不是八题自主 Agent 成绩 |
| v4.2 通用关系剖析定点确认 | 商品 **7/11，整题失败** | 12 次 Flash 调用，保守估算 $0.076260；没有额外业务契约辅助 |
| v4.3 项目契约辅助继续修复 | 商品原 pytest **11/11** | 从 v4.2 失败候选继续，显式安装项目业务契约；4 次 Flash 调用，62,455 Tokens，保守估算 $0.021761 |

v4.3 最终目标构建和原 pytest 均通过，停止原因仍记录为 `step_limit`。它是已有失败候选加 `project_configuration` 的继续修复，不是原工单无辅助盲测，也没有形成自主四题 4/4 成绩。此次两段定点执行合计估算 $0.098021，原失败保留。[成品验收](results/acceptance/public_fixes_20261026.json)、[v4.2](results/v42_relationship_product_20261026.json)、[v4.3](results/v43_contract_repair_20261026.json)可逐条核对。

孤儿产品键、唯一变体归属和事实保全的依据见 [差异诊断](docs/PUBLIC_REMAINING_ISSUE.md)；通用能力见 [关系剖析](docs/RELATIONSHIP_CHECKS.md)。[完整验收](docs/ACCEPTANCE.md)和[公开工程讲解](docs/PUBLIC_PROJECT_GUIDE.md)说明环境与复现边界。

最终软件回归 **222 项通过**，另有 **14 项真实 dbt fixture 测试通过**。新增四题和成品复验未调用模型 API。时区题原有的主键质量失败仍可见，按上游物化/pytest协议通过；范围、9次尝试和逐题证据见 [八题成品说明](docs/PUBLIC_EIGHT_TASKS.md)。

## 运行

已配置的本机环境：

```powershell
pwsh -File scripts/start.ps1
```

打开 <http://127.0.0.1:8000>。选择任务和模式，再启动运行。历史记录可以直接回放，不消耗模型 API；界面会明确标注回放来源。

全新环境（Python 3.11+，推荐 3.12）：

```powershell
pwsh -File scripts/setup.ps1
```

在 `.env` 设置 `DEEPSEEK_API_KEY`，再运行启动脚本。密钥只在服务端使用；`.env` 已忽略提交。运行和评测会产生模型 API 费用，估算价格与预算上限均可在 `.env` 调整。

当前运行仅允许 `deepseek-flash`，默认启用思考、每题最多 12 次调用和 $0.125 估算预算；发送前检查下一次请求的预算，网络和 HTTP 错误不自动重试。公开执行按已授权协议固定任务、调用数与总预算，不自动追加轮次或多模式对照；v4.1 两轮与后续定点修复分开记录。历史费用口径及记录边界见 [费用盘点](docs/COSTS.md)。

Linux/macOS：

```bash
python3 -m venv .venv
.venv/bin/python -m pip install -r requirements.lock
.venv/bin/python -m pip install -e . --no-deps
cp .env.example .env
# Edit .env locally, then:
.venv/bin/python -m datapatch.cli serve
```

容器方式：`docker compose up --build`。当前交付机器没有 Docker，因此容器配置未在该机实测；已验证的是 Windows 本地执行方式。Native 模式面向本项目的可信 SQL 工程，不是操作系统级沙盒。网页默认只监听本机地址。

## 演示内容

- 订单、支付、明细多表关联造成的金额放大。
- 退款记录遗漏与零分母比率。
- UTC 与业务时区的日界错误。
- 同一人的多账号归并与复购统计。
- 增量模型重跑幂等性。
- 新建客户净收入数据集市。

每类包含 `dev` 和 `holdout` 两个固定种子数据集。**holdout 是相同业务问题的新数据，不代表未知任务或跨行业泛化。** Agent 只能访问生成的工作区；Python 参考计算与最终验收器不在其工具路径内。

![真实运行的数据变化证据](docs/screenshots/workbench-evidence.png)

## 架构与实验模式

```text
FastAPI / CLI
     │
 RunService ── run.json + events.jsonl + patch.diff + data_evidence.json
     │
 DeepSeek tool loop
     ├─ file reads / SQL exploration / model writes / dbt
     ├─ schema + model dependency tools + bounded relationship profiles
     ├─ visible business contracts + bounded repair
     └─ at most one budgeted candidate review (verified, call limit >= 6)
     │ agent stops
 Independent evaluator ── Python oracle / source integrity / replay checks
     │
 Offline audit ── protocol / score / usage / summary / archived source
```

| 模式 | 行为 |
|---|---|
| baseline | 一次模型调用生成补丁；不获取执行反馈 |
| react | 通用文件、SQL、dbt 工具循环 |
| context | react 加表结构和模型依赖上下文及工具 |
| verified | context 加可见契约、交付检查和预算内一次候选语义复核；将反馈交还执行器 |

所有模式最后都由同一执行器构建、由同一独立验收器评分。最终验收结果不会回传 Agent。可见检查也存在于 dbt 工程中，普通 Agent 可以通过 `dbt test/build` 获取它们；专用模式不垄断测试信息。

工作台「数据变化」将已记录的修复前后行数、schema、有效业务键上的新增／移除／变更样本与规则状态并排展示。变化用于解释影响，正确性由独立验收判断。语义复核使用同一模型的独立上下文，计入最大调用数；少于 6 次调用的短修复跳过复核，其意见也不能代替验收。公开业务契约由调用方显式安装，来源、文件哈希和原始候选哈希随记录保存。

## 真实评测

```powershell
.\.venv\Scripts\python.exe -m datapatch.cli eval --modes verified --tasks refund_reconciliation_holdout --repeats 1 --workers 1 --max-steps 12 --name my_smoke
```

协议在第一条请求前保存：任务、模型、预算、重复次数、源代码摘要；原始记录、错误与失败不删除。结果写在 `artifacts/evaluations/`，逐次运行在 `artifacts/runs/<run_id>/`。费用是配置单价的保守估算，服务商实际账单为准。

无需模型费用的结果核验：

```powershell
.\.venv\Scripts\python.exe scripts/audit_results.py results --output artifacts/audits/exported_results.json
```

它核验交付报告、完整任务矩阵、评分与构建一致性、计数、汇总、源码归档。保留的历史未修订报告明确排除；证据缺失单列 warning。详细说明见 [离线审计](docs/EVALUATION_AUDIT.md)。

交付结果见 [评测报告](docs/RESULTS.md)。对照关注完整任务成功、重复一致性、运行成本与耗时；小样本不预设显著提升，也不承诺专用模式一定更强。

外部 data-eng-bench 适配、固定上游版本、下载校验和本地复现边界见 [公开基准说明](docs/PUBLIC_BENCHMARK.md)。该适配的 Native 子集结果不称为官方 Harbor 全量榜单成绩。

## 需要看懂和修改的部分

- [代码阅读与修改清单](docs/CODE_READING.md)：关键函数、建议亲手改的两处、验证方式。
- [面试讲解](docs/INTERVIEW.md)：90 秒与 3 分钟讲法、技术追问、成果边界。
- [三分钟演示](docs/DEMO.md)：真实运行与已记录运行回放的操作顺序。
- [调研和三轮改进](docs/IMPROVEMENTS.md)：来源、取舍、每轮验收与效果。
- [最终交付验收](docs/ACCEPTANCE.md)：测试、真实 API、界面、源码与审计证据。
- [交给另一位 Agent](docs/HANDOFF.md)：接手基线、审阅与可读化顺序、验收和分段讲解要求。

核心文件：`agent.py` 负责工具循环；`workspace.py` 负责执行；`context.py` 负责聚焦上下文和关系剖析；`integrations/harbor_agent.py` 安装显式公开契约并适配原测试；`review.py` 负责候选复核；`evidence.py` 负责数据变化；`fixtures.py` 负责数据与独立参考计算；`evaluation.py`／`audit.py` 负责实验与报告核验；`service.py` 负责持久化。

## 测试

```powershell
.\.venv\Scripts\python.exe -m pytest -q
```

测试覆盖原始缺陷确实失败、独立修复后逐行正确、数据不可篡改、增量重复运行、工具边界、验证反馈循环、统计定义和网页 API。测试替身只用于软件测试，不进入真实模型评测或成品回放。

## 数据与开源说明

本项目原始代码采用 MIT License。自建零售数据为固定随机种子生成，包含刻意设计的边界条件，不使用真实个人信息。

外部数据工程基准来自 [Snowflake-Labs/data-eng-bench](https://github.com/Snowflake-Labs/data-eng-bench)，遵循其 Apache-2.0 与 NOTICE。外部大文件、密钥、参考解法和本地运行目录不纳入源码提交。第三方来源及复现条件见 `docs/PUBLIC_BENCHMARK.md`。
