from __future__ import annotations

import copy
import hashlib
import importlib.util
import json
import zipfile
from pathlib import Path

import pytest

from datapatch.evaluation import summarize

ROOT = Path(__file__).resolve().parents[1]
spec = importlib.util.spec_from_file_location("audit_under_test", ROOT / "scripts/audit_draft.py")
audit_module = importlib.util.module_from_spec(spec)
assert spec.loader is not None
spec.loader.exec_module(audit_module)
audit_report, audit_reports = audit_module.audit_report, audit_module.audit_reports


def example_report() -> dict:
    rows = [{"run_id": "trial-1", "task_id": "one", "mode": "verified", "repeat": 0, "status": "completed", "verification": {"passed": True}, "final_build": {"success": True}, "metrics": {"prompt_tokens": 100, "completion_tokens": 20, "total_tokens": 120, "model_calls": 2, "tool_calls": 3, "estimated_cost_usd": 0.01, "elapsed_seconds": 3.2}}]
    return {"status": "completed", "planned_trials": 1, "protocol": {"task_ids": ["one"], "modes": ["verified"], "repeats": 1}, "records": rows, "summary": summarize(rows)}


def error_codes(result: dict) -> set[str]:
    return {item["code"] for item in result["errors"]}


def test_valid_report_warns_about_unavailable_source_without_claiming_source_pass():
    result = audit_report(example_report())
    assert result["passed"] is True
    assert any(item["code"] == "source_unverifiable" for item in result["warnings"])
    assert not any(item["code"] == "report_source_hash" and item["status"] == "passed" for item in result["checks"])


def test_tampered_summary_is_detected():
    report = example_report()
    report["summary"][0]["total_tokens"] += 1
    assert "summary_matches_records" in error_codes(audit_report(report))


def test_duplicate_run_id_and_duplicate_protocol_trial_are_detected():
    report = example_report()
    report["records"].append(copy.deepcopy(report["records"][0]))
    report["summary"] = summarize(report["records"])
    codes = error_codes(audit_report(report))
    assert {"duplicate_run_id", "duplicate_trial", "trial_count"} <= codes


def test_missing_matrix_trial_is_detected_even_if_summary_is_self_consistent():
    report = example_report()
    report["protocol"]["task_ids"].append("two")
    report["planned_trials"] = 2
    assert {"missing_trials", "trial_count"} <= error_codes(audit_report(report))


@pytest.mark.parametrize("field", ["status", "final_build"])
def test_false_pass_after_failed_execution_or_build_is_rejected(field):
    report = example_report()
    report["records"][0][field] = "failed" if field == "status" else {"success": False}
    report["summary"] = summarize(report["records"])
    codes = error_codes(audit_report(report))
    assert ("passed_incomplete_execution" if field == "status" else "passed_failed_build") in codes


@pytest.mark.parametrize("tamper,code", [("tokens", "token_sum"), ("cost", "nonnegative_measure")])
def test_inconsistent_tokens_and_negative_cost_are_rejected(tamper, code):
    report = example_report()
    if tamper == "tokens":
        report["records"][0]["metrics"]["total_tokens"] = 1
    else:
        report["records"][0]["metrics"]["estimated_cost_usd"] = -0.1
    report["summary"] = summarize(report["records"])
    assert code in error_codes(audit_report(report))


def make_snapshot(path: Path, *, manifest: bool) -> str:
    name, data = "src/datapatch/example.py", b"VALUE = 1\n"
    digest = hashlib.sha256(b"example.py" + data).hexdigest()
    with zipfile.ZipFile(path, "w") as archive:
        archive.writestr(name, data)
        if manifest:
            archive.writestr("source-manifest.json", json.dumps({"core_source_sha256": digest, "files": [{"path": name, "sha256": hashlib.sha256(data).hexdigest()}]}))
    return digest


@pytest.mark.parametrize("manifest", [True, False])
def test_source_hash_can_be_verified_with_manifest_or_legacy_zip(tmp_path, manifest):
    report = example_report()
    path = tmp_path / "example_source.zip"
    report["protocol"]["source_sha256"] = make_snapshot(path, manifest=manifest)
    report["source_snapshot"] = str(path)
    result = audit_report(report)
    assert result["passed"]
    assert any(item["code"] == "report_source_hash" and item["status"] == "passed" for item in result["checks"])
    if not manifest:
        assert any(item["code"] == "legacy_source_manifest_missing" for item in result["warnings"])


def test_mismatched_source_hash_is_an_error(tmp_path):
    report = example_report()
    path = tmp_path / "example_source.zip"
    make_snapshot(path, manifest=True)
    report["source_snapshot"] = str(path)
    report["protocol"]["source_sha256"] = "0" * 64
    assert "report_source_hash" in error_codes(audit_report(report))


def test_history_is_explicitly_excluded_but_include_history_exposes_bad_grade(tmp_path):
    report = example_report()
    current = tmp_path / "example.json"
    current.write_text(json.dumps(report), encoding="utf-8")
    report["records"][0]["status"] = "failed"
    report["summary"] = summarize(report["records"])
    history = tmp_path / "example_unamended.json"
    history.write_text(json.dumps(report), encoding="utf-8")
    result = audit_reports([current, history])
    assert result["passed"] and len(result["excluded_reports"]) == 1
    assert "passed_incomplete_execution" in error_codes(audit_reports([current, history], include_unamended=True))


def test_empty_selection_is_not_reported_as_a_pass():
    assert "no_reports" in error_codes(audit_reports([]))


def test_real_local_reports_are_audited_read_only():
    paths = list((ROOT / "artifacts/evaluations").glob("*.json"))
    if not paths:
        pytest.skip("No saved local reports")
    before = {path: hashlib.sha256(path.read_bytes()).hexdigest() for path in paths}
    result = audit_reports(paths)
    assert result["passed"], result["errors"]
    assert before == {path: hashlib.sha256(path.read_bytes()).hexdigest() for path in paths}
