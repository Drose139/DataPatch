"""The auditable tool loop and the four experimental conditions."""
from __future__ import annotations

import json
import time
from typing import Callable

from .config import Settings
from .provider import DeepSeekClient
from .workspace import Workspace, tool_definitions

MODES = ("baseline", "react", "context", "verified")

SYSTEM_PROMPT = """You are DataPatch, an agent that implements data-engineering tickets in a local dbt/DuckDB project.
Use evidence from source models and live data, then make a minimal correct change. Never claim a fix without executing it.
You may only edit SQL files under the project's models/ directory. Preserve the requested output table, grain, column names,
and business rules. Do not alter tests, input data, profiles, or evaluation code. Reference solutions and final evaluation
are unavailable. The SQL query tool is read-only; use dbt to materialize model changes. A query can inspect information_schema.
Read the project's README or task instruction for the full business contract before editing.
When finished, provide a short Chinese handoff explaining the cause, change, verification and limitations.
All file paths are relative to the task workspace. Finish within the available call budget.
"""


class Agent:
    def __init__(self, workspace: Workspace, config: Settings, mode: str = "verified", emit: Callable[[dict], None] | None = None, client=None):
        if mode not in MODES:
            raise ValueError(f"Unknown mode: {mode}")
        self.workspace = workspace
        self.config = config
        self.mode = mode
        self.emit = emit or (lambda event: None)
        self.client = client or DeepSeekClient(config)
        self.metrics = {"model_calls": 0, "tool_calls": 0, "prompt_tokens": 0, "completion_tokens": 0, "total_tokens": 0, "estimated_cost_usd": 0.0}

    def _response(self, messages: list[dict], tools: list[dict] | None) -> dict:
        if self.metrics["estimated_cost_usd"] >= self.config.run_budget_usd:
            raise RuntimeError("达到单任务估算费用上限，已停止模型调用")
        result = self.client.complete(messages, tools)
        self.metrics["model_calls"] += 1
        usage = result.get("usage", {})
        for key in ("prompt_tokens", "completion_tokens", "total_tokens"):
            self.metrics[key] += int(usage.get(key, 0))
        self.metrics["estimated_cost_usd"] += result.get("estimated_cost_usd", 0)
        self.emit({"type": "model", "name": result.get("model"), "content": result["message"].get("content") or "模型请求工具执行", "usage": usage, "response_id": result.get("response_id"), "latency_seconds": result.get("latency_seconds"), "metrics": dict(self.metrics)})
        return result

    def run(self, instruction: str) -> dict:
        started = time.monotonic()
        initial_context = {"files": self.workspace.list_files(), "project_directory": str(self.workspace.project_dir.relative_to(self.workspace.root)).replace("\\", "/"), "database": self.workspace.database_path.name}
        if self.mode in {"context", "verified"}:
            initial_context["schema"] = self.workspace.search_schema()
            initial_context["lineage"] = self.workspace.get_lineage()
        if self.mode == "baseline":
            return self._single_patch(instruction, initial_context, started)
        prompt = SYSTEM_PROMPT
        if self.mode == "verified":
            prompt += "\nBefore handoff, execute build and check_contracts. Investigate counterexamples and repair failures within budget. For incremental models, consider a second run or full refresh when appropriate. Visible checks are necessary but not sufficient for correctness."
        messages = [{"role": "system", "content": prompt}, {"role": "user", "content": instruction + "\n\nWorkspace overview:\n" + json.dumps(initial_context, ensure_ascii=False, default=str)}]
        tools = tool_definitions(domain_tools=self.mode in {"context", "verified"}, validation_tools=self.mode == "verified")
        allowed_names = {tool["function"]["name"] for tool in tools}
        final = ""
        stop_reason = "step_limit"
        validation = None
        for step in range(self.config.max_steps):
            response = self._response(messages, tools)
            raw_message = response["message"]
            # Preserve reasoning_content for API providers requiring round-trip continuity;
            # do not expose hidden reasoning through the event log or UI.
            message = {key: value for key, value in raw_message.items() if key in {"role", "content", "tool_calls", "reasoning_content"} and value is not None}
            message.setdefault("role", "assistant")
            messages.append(message)
            calls = message.get("tool_calls", [])
            if calls:
                for call in calls[:8]:
                    name = call["function"]["name"]
                    began = time.monotonic()
                    arguments = {}
                    try:
                        arguments = json.loads(call["function"].get("arguments", "{}"))
                        if name not in allowed_names:
                            raise ValueError("该实验条件未启用此工具")
                        result = self.workspace.call(name, arguments)
                    except Exception as exc:
                        result = {"error": str(exc)[:3000], "error_type": type(exc).__name__}
                    self.metrics["tool_calls"] += 1
                    self.emit({"type": "tool", "name": name, "step": step + 1, "arguments": arguments, "result": result, "elapsed_seconds": round(time.monotonic() - began, 3), "metrics": dict(self.metrics)})
                    messages.append({"role": "tool", "tool_call_id": call["id"], "content": json.dumps(result, ensure_ascii=False, default=str)[:22000]})
                # Normally providers emit at most a handful of calls. Every call needs a reply.
                for call in calls[8:]:
                    messages.append({"role": "tool", "tool_call_id": call["id"], "content": '{"error":"Too many parallel calls; retry in a smaller batch"}'})
                continue
            final = message.get("content", "") or ""
            if self.mode == "verified":
                build = self.workspace.run_dbt("build")
                validation = self.workspace.check_contracts()
                self.metrics["tool_calls"] += 2
                self.metrics["handoff_gates"] = self.metrics.get("handoff_gates", 0) + 1
                self.emit({"type": "validation", "name": "handoff_gate", "result": {"build": build, "contracts": validation}})
                if not build["success"] or not validation["passed"]:
                    messages.append({"role": "user", "content": "交付前检查未通过。请依据这些可见执行反馈继续修复；不要声称已经成功：\n" + json.dumps({"build": build, "contracts": validation}, ensure_ascii=False, default=str)[:16000]})
                    continue
            stop_reason = "model_finished"
            break
        self.metrics["elapsed_seconds"] = round(time.monotonic() - started, 3)
        self.metrics["estimated_cost_usd"] = round(self.metrics["estimated_cost_usd"], 6)
        self.emit({"type": "final", "content": final or "已达到调用上限，请审阅最终独立验收结果。", "stop_reason": stop_reason, "metrics": dict(self.metrics)})
        return {"final_answer": final, "metrics": self.metrics, "stop_reason": stop_reason, "visible_validation": validation, "model": self.config.model}

    def _single_patch(self, instruction: str, context: dict, started: float) -> dict:
        files = {}
        for path in self.workspace.list_files()["files"]:
            if path.endswith((".sql", ".md", ".yml")) and not path.startswith("checks/"):
                files[path] = self.workspace.read_file(path)["content"]
        context["source_files"] = files
        context["schema"] = self.workspace.search_schema()
        messages = [{"role": "system", "content": SYSTEM_PROMPT + '\nYou have one model call and no tools. Return ONLY JSON: {"files":[{"path":"models/...sql","content":"..."}],"explanation":"..."}.'}, {"role": "user", "content": instruction + "\n" + json.dumps(context, ensure_ascii=False, default=str)}]
        response = self._response(messages, None)
        content = response["message"].get("content", "")
        cleaned = content.strip()
        if cleaned.startswith("```"):
            cleaned = cleaned.split("\n", 1)[1].rsplit("```", 1)[0]
        data = json.loads(cleaned)
        for patch in data.get("files", []):
            result = self.workspace.write_model(patch["path"], patch["content"])
            self.emit({"type": "tool", "name": "write_model", "arguments": patch, "result": result})
            self.metrics["tool_calls"] += 1
        self.metrics["elapsed_seconds"] = round(time.monotonic() - started, 3)
        return {"final_answer": data.get("explanation", ""), "metrics": self.metrics, "stop_reason": "single_patch", "model": self.config.model}
