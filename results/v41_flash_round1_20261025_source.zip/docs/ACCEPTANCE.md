# 交付验收记录

日期：2026-10-25。项目：DataPatch。执行环境：Windows、Python 3.12.2、DuckDB 1.5.6、dbt-core 1.12.6、dbt-duckdb 1.11.0；依赖锁定在 `requirements.lock`。

| 验收对象 | 实际结果 | 证据 |
|---|---|---|
| 任务数据与独立 Oracle | 14 项真实 dbt fixture 测试通过；原始缺陷失败、参考修复逐行通过、源完整性及重复 delivery 验收 | `tests/test_fixtures.py`；本轮没有修改数据生成、Oracle 与重放语义 |
| 最终软件回归 | **63 passed**，7.42 秒；一条测试客户端弃用提示，无测试失败 | Agent、上下文、工具、API、服务、证据、复核和审计测试；其中 audit 24 项 |
| 最终依赖 | `pip check` 无冲突 | 当前 `.venv` 与 lock |
| 第一轮数据证据 | 7 项证据测试；真实回归 **2/2**；桌面及手机实际 UI 通过 | [第一轮报告](../results/round1_evidence_20261025.json)、[界面验收](../results/validation/round1_evidence_ui_20261025.json) |
| 第二轮复核，修订后 | 六道合成任务 **6/6**，191,325 Tokens，估算 $0.063835 | [实际报告](../results/round2b_contract_review_20261025.json)；修订前 5/6 原样保留 |
| 最终真实 API smoke | 同一退款 holdout：Baseline **1/1**、Verified **1/1**；Verified 包含一次实际候选复核 | [最终报告](../results/final_acceptance_20261025.json) |
| 正式结果审计 | 10 份报告、1,463 项检查；**0 errors**、4 个明确历史 warning；源报告未修改 | [本地产物审计](../results/validation/final_audit_20261025.json)、[导出结果审计](../results/validation/exported_audit_20261025.json) |
| 界面 | 本地真实服务、桌面与 390px 手机；只读浏览，不产生模型调用 | [最终 UI 验收](../results/validation/final_ui_20261025.json) |

最终 API smoke 的 Verified Run ID 为 `42fdb20f-0177-4f84-a529-f29b5b6803da`：8 次模型调用、12 次工具调用、20,401 Tokens，完整执行 85.48 秒，估算 $0.007141。Baseline Run ID 为 `dc4496b4-581d-4bc2-aeb4-313f1da328ef`，一次模型调用、1,722 Tokens，估算 $0.000777。它们是功能验收，不是对两种策略能力的统计比较。

最终核心源代码摘要：`dbb7416bebfbaabb4085801156464f372fdd3920b8c1c47e8776791246c377bc`。对应 [最终验收源码归档](../results/final_acceptance_20261025_source.zip)。各历史实验按各自冻结版本解释。

审计四项 warning：首次公开实验没有源码 zip；两份早期归档没有 manifest，但核心源码摘要绑定通过；未修订历史报告被明确排除。后续归档均核验逐文件哈希。审计通过表示记录和计算自洽，不改变业务通过率。

公开 data-eng-bench 的最终两题仍 **0/2**，组件为 12/13、14/15；退款窗口总体与额外状态过滤仍有业务错误。完整失败保存在结果中。当前没有 Docker，容器配置未作本机实测；已经实测的是本地可信 SQL 项目的执行与展示。

调研来源、三轮改进、失败和修订理由见 [IMPROVEMENTS.md](IMPROVEMENTS.md)。接手顺序见 [CODE_READING.md](CODE_READING.md)，面试讲法和简历 bullet 见 [INTERVIEW.md](INTERVIEW.md)。
