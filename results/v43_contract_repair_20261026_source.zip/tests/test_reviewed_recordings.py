from __future__ import annotations

import hashlib
import importlib.util
import json
from pathlib import Path

import pytest


spec = importlib.util.spec_from_file_location("reviewed_recordings", Path(__file__).resolve().parents[1] / "scripts/export_reviewed_recordings.py")
recordings = importlib.util.module_from_spec(spec)
assert spec.loader is not None
spec.loader.exec_module(recordings)


def write_json(path, value):
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_bytes((json.dumps(value, ensure_ascii=False, indent=2) + "\n").encode())


def write_bytes(path, value):
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_bytes(value)
    return hashlib.sha256(value).hexdigest()


@pytest.fixture
def acceptance(tmp_path):
    snapshot = tmp_path / "external/public-snapshot"
    database = snapshot / "base-image/database/retail.duckdb"
    database_hash = write_bytes(database, b"database is only hashed, never opened")
    tasks = ("public-create-any-name", "public-fix-any-name")
    lock = {"repository": "example/public", "commit": "pinned", "tasks": list(tasks),
            "database": {"bytes": database.stat().st_size, "sha256": database_hash}, "files": []}
    rows = []
    for index, task in enumerate(tasks):
        model_path = "models/marts/" + task + ".sql"
        instruction = snapshot / "tasks" / task / "instruction.md"
        write_bytes(instruction, ("# Original public task " + task + "\nPublic requirements.").encode())
        initial_paths = [instruction]
        if index:
            buggy = snapshot / "tasks" / task / "environment/data" / Path(model_path).name
            write_bytes(buggy, b"select 1 / 0 as broken\n")
            initial_paths.append(buggy)
        inputs = [{"path": p.relative_to(snapshot).as_posix(), "sha256": recordings._sha256(p), "bytes": p.stat().st_size} for p in initial_paths]
        lock["files"].extend(inputs)
        patch = tmp_path / "examples/public_fixes" / (task + ".sql")
        patch_hash = write_bytes(patch, b"-- operator_reviewed\nselect 42 as fixed\n")
        case = tmp_path / "external/fresh-cases" / task
        write_bytes(case / "project" / model_path, patch.read_bytes())
        preparation = {"task_id": task, "upstream_commit": "pinned", "task_type": "fix-model" if index else "create-model", "project_dir": str(case / "project")}
        write_json(case / "native-case.json", preparation)
        build = {"success": True, "target_model_success": True, "stdout": "ACTUAL SAVED BUILD", "returncode": 0}
        archive = tmp_path / "artifacts/acceptance/evidence" / task
        build_path = archive / "build.json"
        write_json(build_path, build)
        verifier = archive / "verifier/result.json"
        original_hash = write_bytes(verifier.parent / "test_outputs.original.py", b"ORIGINAL PUBLIC TEST BYTES")
        adapted_hash = write_bytes(verifier.parent / ("test_outputs_" + task.replace("-", "_") + ".py"), b"PATH ADAPTED ORIGINAL TEST BYTES")
        raw = {"returncode": 0, "reward": 1.0, "stdout": "11 passed in 1.23s", "original_sha256": original_hash,
               "adapted_sha256": adapted_hash, "components_passed": [], "components_failed": [], "grading_protocol": "pytest_exit_status",
               "pytest_returncode": 0, "pytest_counts": {"passed": 11, "failed": 0, "errors": 0, "skipped": 0},
               "scoring_source_sha256": write_bytes(verifier.parent / "test.original.sh", b"ORIGINAL PUBLIC SCORING BYTES")}
        if index:
            raw.update({"grading_protocol": "component_reward_json", "components_passed": ["component_real_1", "component_real_2"]})
        write_json(verifier, raw)
        rows.append({"task_id": task, "patch_origin": "operator_reviewed", "zero_api_calls": True,
                     "patch_source": str(patch), "patch_sha256": patch_hash, "applied_patch_sha256": patch_hash,
                     "model_path": model_path, "case_directory": str(case), "status": "completed", "build": build,
                     "verification": {"passed": True, "original_tests_passed": True, "reward": 1.0}, "errors": [],
                     "input_files": inputs, "preparation": preparation, "elapsed_seconds": 5.5,
                     "artifacts": {"build_report": str(build_path), "verifier_report": str(verifier)}, "raw_verifier": raw})
    lock_path = snapshot / "snapshot-lock.json"
    write_json(lock_path, lock)
    report = {"type": "reviewed_patch_acceptance", "name": "actual-reviewed-acceptance", "patch_origin": "operator_reviewed",
              "zero_model_api_calls": True, "planned_tasks": 2, "status": "completed", "protocol": {"task_ids": list(tasks)},
              "input_snapshot": {"repository": "example/public", "commit": "pinned", "snapshot_lock": str(lock_path),
                                 "snapshot_lock_sha256": recordings._sha256(lock_path), "database_sha256": database_hash,
                                 "database_bytes": database.stat().st_size}, "records": rows, "summary": {"accepted": 2}}
    path = tmp_path / "results/acceptance/actual-reviewed-acceptance.json"
    write_json(path, report)
    return tmp_path, path, report


def test_exports_real_artifacts_with_zero_model_metrics_and_explicit_reviewed_provenance(acceptance):
    root, path, report = acceptance
    paths, audit = recordings.export_report(path, project_root=root)
    assert audit["passed"] and audit["input_files_checked"] == 3
    assert len(paths) == 2
    for target, row in zip(paths, report["records"]):
        run = json.loads(target.read_text(encoding="utf-8"))
        assert run["provider"] == "operator_reviewed" and run["mode"] == "reviewed_patch" and run["model"] == "未调用模型"
        assert "不属于自主 Agent 成绩" in run["recording_source"]
        assert run["metrics"] == {"elapsed_seconds": 5.5, "model_calls": 0, "tool_calls": 0, "prompt_tokens": 0,
                                  "completion_tokens": 0, "total_tokens": 0, "estimated_cost_usd": 0}
        assert run["final_build"] == row["build"] and run["raw_verifier"] == row["raw_verifier"]
        assert run["verification"]["passed"] is True and "data_evidence" not in run
        assert all(event["type"] != "model" and "timestamp" not in event for event in run["events"])
        assert "started_at" not in run and "finished_at" not in run
        assert str(root) not in target.read_text(encoding="utf-8") and "$PROJECT" in str(run["source_artifacts"])
        assert "Original public task" in run["task"]["title"] and "Public requirements." in run["task"]["description"]
    created, fixed = [json.loads(p.read_text(encoding="utf-8")) for p in paths]
    assert "--- /dev/null" in created["diff"] and "+select 42 as fixed" in created["diff"]
    assert "-select 1 / 0 as broken" in fixed["diff"] and "+select 42 as fixed" in fixed["diff"]
    assert any(c["name"] == "component_real_2" for c in fixed["checks"])
    assert next(c for c in created["checks"] if c["name"] == "pytest_executed_tests")["actual"] == 11


def test_failed_original_pytest_remains_failed_not_upgraded_by_successful_build(acceptance):
    root, path, report = acceptance
    row = report["records"][0]
    row["raw_verifier"].update({"returncode": 1, "reward": 0.0, "pytest_returncode": 1,
                               "stdout": "8 passed, 3 failed in 1.23s", "pytest_counts": {"passed": 8, "failed": 3, "errors": 0, "skipped": 0}})
    row["verification"].update({"passed": False, "original_tests_passed": False, "reward": 0.0})
    report["summary"]["accepted"] = 1
    write_json(Path(row["artifacts"]["verifier_report"]), row["raw_verifier"])
    write_json(path, report)
    paths, _ = recordings.export_report(path, project_root=root)
    run = json.loads(paths[0].read_text(encoding="utf-8"))
    assert run["status"] == "completed" and run["verification"]["passed"] is False
    assert next(c for c in run["checks"] if c["name"] == "pytest_no_failures")["actual"] == 3
    assert "未通过" in run["final_answer"]


def test_public_copy_with_workspace_paths_redacted_still_binds_original_artifacts(acceptance):
    root, path, report = acceptance
    row = report["records"][0]
    row["raw_verifier"]["stdout"] += "\nworkspace: " + str(root)
    write_json(Path(row["artifacts"]["verifier_report"]), row["raw_verifier"])
    write_json(path, recordings._clean(report, {str(root)}))
    paths, audit = recordings.export_report(path, project_root=root)
    assert len(paths) == 2 and audit["passed"]
    assert "$PROJECT" in paths[0].read_text(encoding="utf-8")


@pytest.mark.parametrize("source", ["patch", "applied_sql", "verifier", "input"])
def test_source_byte_or_saved_artifact_tampering_refuses_export(acceptance, source):
    root, path, report = acceptance
    row = report["records"][0]
    targets = {"patch": Path(row["patch_source"]),
               "applied_sql": Path(row["case_directory"]) / "project" / row["model_path"],
               "verifier": Path(row["artifacts"]["verifier_report"]),
               "input": Path(report["input_snapshot"]["snapshot_lock"]).parent / row["input_files"][0]["path"]}
    targets[source].write_bytes(b"CHANGED SOURCE")
    with pytest.raises((ValueError, json.JSONDecodeError)):
        recordings.export_report(path, project_root=root)
    assert not (root / "examples/recorded_runs").exists()


def test_running_report_is_rejected_and_existing_recordings_are_preserved(acceptance):
    root, path, report = acceptance
    report["status"] = "running"
    write_json(path, report)
    with pytest.raises(ValueError, match="completed"):
        recordings.export_report(path, project_root=root)
    report["status"] = "completed"
    write_json(path, report)
    paths, _ = recordings.export_report(path, project_root=root)
    original = [p.read_bytes() for p in paths]
    again, _ = recordings.export_report(path, project_root=root)
    assert again == paths and [p.read_bytes() for p in paths] == original
    paths[0].write_bytes(b"HISTORICAL RECORDING")
    with pytest.raises(ValueError, match="refusing overwrite"):
        recordings.export_report(path, project_root=root)
    assert paths[0].read_bytes() == b"HISTORICAL RECORDING" and paths[1].read_bytes() == original[1]
