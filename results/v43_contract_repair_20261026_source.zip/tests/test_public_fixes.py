from __future__ import annotations

import hashlib
import importlib.util
import json
from pathlib import Path

import pytest

spec = importlib.util.spec_from_file_location("public_fixes", Path(__file__).resolve().parents[1] / "scripts/verify_public_fixes.py")
fixes = importlib.util.module_from_spec(spec)
assert spec.loader is not None
spec.loader.exec_module(fixes)


@pytest.fixture
def offline_acceptance(tmp_path, monkeypatch):
    patches, snapshot = tmp_path / "patches", tmp_path / "snapshot"
    patches.mkdir()
    database = snapshot / "base-image/database/retail.duckdb"
    database.parent.mkdir(parents=True)
    database.write_bytes(b"original-input-database")
    lock = {"repository": fixes.adapter.REPOSITORY, "commit": fixes.adapter.PINNED_COMMIT,
            "tasks": list(fixes.DEFAULT_TASKS), "database": {"bytes": database.stat().st_size, "sha256": hashlib.sha256(database.read_bytes()).hexdigest()}, "files": []}
    (snapshot / "snapshot-lock.json").write_text(json.dumps(lock), encoding="utf-8")
    for task in fixes.DEFAULT_TASKS:
        (patches / (task + ".sql")).write_bytes(b"-- operator_reviewed\nselect 42 as reviewed_result\n")
    state = {"events": [], "reject": None, "targets": []}

    def prepare(source, case, task):
        state["events"].append((task, "prepare"))
        (case / "project/models").mkdir(parents=True)
        (case / "project/models/unrelated.sql").write_text("KEEP ME", encoding="utf-8")
        (case / "task.txt").write_text(task, encoding="utf-8")
        return {"task_id": task, "initialized": True}

    class FakeWorkspace:
        def __init__(self, root, project_dir, database_path):
            self.case = root
        def run_dbt(self, command, select):
            task = (self.case / "task.txt").read_text(encoding="utf-8")
            state["events"].append((task, "build"))
            assert command == "build" and select == Path(fixes.adapter.PUBLIC_TASK_MODELS[task]).stem
            target = self.case / "project" / fixes.adapter.PUBLIC_TASK_MODELS[task]
            assert target.read_bytes() == (patches / (task + ".sql")).read_bytes()
            assert (self.case / "project/models/unrelated.sql").read_text(encoding="utf-8") == "KEEP ME"
            state["targets"].append(target)
            return {"success": True, "stdout": "ORIGINAL BUILD STDOUT", "stderr": ""}

    def verify_build(build, project, model):
        return {**build, "target_model_success": True, "target_model": Path(model).stem}

    def evaluate(case, evaluator_root):
        task = (case / "task.txt").read_text(encoding="utf-8")
        state["events"].append((task, "pytest"))
        assert not evaluator_root.is_relative_to(case)
        rejected = task == state["reject"]
        raw = {"returncode": int(rejected), "reward": 0.0 if rejected else 1.0,
               "stdout": "1 failed in 0.1s" if rejected else "1 passed in 0.1s",
               "components_passed": [] if rejected else ["component_1_model_compiles"],
               "components_failed": ["component_1_model_compiles"] if rejected else [], "grading_protocol": "component_reward_json"}
        if task == "dbt-fix-product-metrics":
            raw.update({"grading_protocol": "pytest_exit_status", "pytest_returncode": int(rejected),
                        "pytest_counts": {"passed": 0 if rejected else 1, "failed": int(rejected), "errors": 0, "skipped": 0},
                        "components_passed": [], "components_failed": []})
        p = evaluator_root / task / "original-verifier-report.json"
        p.parent.mkdir(parents=True)
        p.write_text(json.dumps(raw), encoding="utf-8")
        return {"report": str(p)}

    monkeypatch.setattr(fixes.adapter, "prepare_native_case", prepare)
    monkeypatch.setattr(fixes.adapter, "verify_target_build", verify_build)
    monkeypatch.setattr(fixes.adapter, "evaluate_native_case", evaluate)
    monkeypatch.setattr(fixes, "Workspace", FakeWorkspace)
    return patches, snapshot, tmp_path / "fresh-cases", tmp_path / "acceptance/report.json", state


def test_all_reviewed_patches_use_original_inputs_and_original_tests_without_agent_metrics(offline_acceptance):
    patches, snapshot, cases, output, state = offline_acceptance
    report = fixes.verify_fixes(patches, cases, output, snapshot=snapshot)
    assert state["events"] == [(task, phase) for task in fixes.DEFAULT_TASKS for phase in ("prepare", "build", "pytest")]
    assert report["type"] == "reviewed_patch_acceptance" and report["patch_origin"] == "operator_reviewed"
    assert report["zero_api_calls"] is True and report["summary"]["accepted"] == report["planned_tasks"] == 4
    assert report["status"] == "completed" and output.is_file() and output.with_suffix(".md").is_file()
    assert "model_calls" not in output.read_text(encoding="utf-8") and "completion_tokens" not in output.read_text(encoding="utf-8")
    for row in report["records"]:
        assert row["patch_sha256"] == row["applied_patch_sha256"]
        assert row["build"]["stdout"] == "ORIGINAL BUILD STDOUT" and row["raw_verifier"]["reward"] == 1
        assert Path(row["artifacts"]["verifier_report"]).is_file()


def test_subset_has_one_task_denominator_and_failure_is_preserved(offline_acceptance):
    patches, snapshot, cases, output, state = offline_acceptance
    state["reject"] = "dbt-fix-product-metrics"
    report = fixes.verify_fixes(patches, cases, output, (state["reject"],), snapshot=snapshot)
    assert report["planned_tasks"] == 1 and report["summary"]["accepted"] == 0
    assert report["records"][0]["verification"]["passed"] is False
    assert len(state["events"]) == 3


def test_existing_case_root_or_report_is_never_overwritten(offline_acceptance):
    patches, snapshot, cases, output, state = offline_acceptance
    cases.mkdir()
    sentinel = cases / "history.txt"
    sentinel.write_text("HISTORY", encoding="utf-8")
    with pytest.raises(ValueError, match="new"):
        fixes.verify_fixes(patches, cases, output, snapshot=snapshot)
    assert sentinel.read_text(encoding="utf-8") == "HISTORY" and not state["events"]


def test_unmarked_patch_is_rejected_before_any_preparation(offline_acceptance):
    patches, snapshot, cases, output, state = offline_acceptance
    (patches / (fixes.DEFAULT_TASKS[0] + ".sql")).write_text("select 1", encoding="utf-8")
    with pytest.raises(ValueError, match="operator_reviewed"):
        fixes.verify_fixes(patches, cases, output, snapshot=snapshot)
    assert not cases.exists() and not output.exists() and not state["events"]


def test_snapshot_hash_mismatch_is_rejected_without_build_or_pytest(offline_acceptance):
    patches, snapshot, cases, output, state = offline_acceptance
    (snapshot / "base-image/database/retail.duckdb").write_bytes(b"modified-inputs")
    with pytest.raises(ValueError, match="database"):
        fixes.verify_fixes(patches, cases, output, snapshot=snapshot)
    assert not cases.exists() and not state["events"]
