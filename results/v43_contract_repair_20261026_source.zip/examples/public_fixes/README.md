# Reviewed public-project delivery patches

These four SQL models are reproducible delivery artifacts for the pinned
Snowflake data-eng-bench public development tasks. They are stored outside
all solver workspaces. They are **operator-reviewed patches**, not four new
autonomous model runs. provenance.json records the original Flash candidate,
original SQL bytes and the reviewed patch hash.

- Refund, customer and inventory SQL retain the recorded passing Flash changes.
- Product SQL repairs orphan product attribution: retain a valid direct product;
  otherwise use an unambiguous variant that maps to an existing product. Verify
  lookup uniqueness and source quantity/revenue reconciliation independently.
- The public project's existing sources and macros remain dependencies.

From the repository root, with the pinned input snapshot already fetched:

```powershell
.venv/Scripts/python.exe scripts/verify_public_fixes.py
```

This creates fresh isolated cases, builds each target, then executes the original
upstream tests outside its workspace. It invokes no model provider. Existing
cases/results are never overwritten; select a new --case-root and --output to
repeat local acceptance. Results are in artifacts/acceptance, separate from
autonomous Agent evaluations. Actual scores are documented after execution.

A fresh Agent run starts from the public project's original inputs and missing
or broken target, not from these patches. Its new context profiles selected
relationships for orphan keys and lookup uniqueness; it must still decide and
validate the requested business semantics.
