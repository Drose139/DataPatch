import json
from pathlib import Path

import duckdb

from datapatch.context import MAX_CONTEXT_CHARS, build_task_context
from datapatch.workspace import Workspace


def _model(root: Path, path: str, sql: str) -> Path:
    target = root / path
    target.parent.mkdir(parents=True, exist_ok=True)
    target.write_text(sql, encoding="utf-8")
    return target


def test_explicit_sql_path_focuses_target_and_relevant_schema(tmp_path):
    sql = "select customer_id, grand_total from {{ ref('int_sales__orders_enriched') }}"
    _model(tmp_path, "models/marts/customer/rpt_customer_metrics.sql", sql)
    _model(tmp_path, "models/intermediate/int_sales__orders_enriched.sql", "select * from {{ ref('stg_orders') }}")
    _model(tmp_path, "models/staging/stg_orders.sql", "select 1 as customer_id")
    with duckdb.connect(str(tmp_path / "warehouse.duckdb")) as db:
        db.execute("create table int_sales__orders_enriched(customer_id varchar,grand_total bigint)")
        db.execute("create table unrelated_alphabetical_first(irrelevant varchar)")
    context = build_task_context(Workspace(tmp_path), "Fix /app/dbt_models_duckdb/models/marts/customer/rpt_customer_metrics.sql; investigate invalid customer metrics.")
    assert context["target"]["path"] == "models/marts/customer/rpt_customer_metrics.sql"
    assert context["target"]["sql"] == sql
    assert context["target"]["identified_by"] == "explicit SQL path in instruction"
    assert any(node["model"] == "int_sales__orders_enriched" for node in context["lineage"]["nodes"])
    assert "main.int_sales__orders_enriched" in context["schema"]["tables"]
    assert "main.unrelated_alphabetical_first" not in context["schema"]["tables"]


def test_budget_truncates_readme_and_schema_before_target_sql(tmp_path):
    sql = "-- target must remain complete\n" + "-- business logic comment\n" * 180 + "select * from {{ ref('customer_source') }}"
    _model(tmp_path, "models/customer_report.sql", sql)
    (tmp_path / "README.md").write_text("Business documentation with escaped quotes \\\" and unicode 客户。\n" * 5000, encoding="utf-8")
    with duckdb.connect(str(tmp_path / "warehouse.duckdb")) as db:
        for table in range(15):
            columns = ",".join(f"long_customer_business_attribute_{n} varchar" for n in range(80))
            db.execute(f"create table customer_source_{table}({columns})")
    context = build_task_context(Workspace(tmp_path), "Repair customer_report customer revenue business logic", focus_model="customer_report")
    assert len(json.dumps(context, ensure_ascii=False)) <= MAX_CONTEXT_CHARS
    assert context["target"]["sql"] == sql
    assert not context["target"]["truncated"]
    assert context["readme"]["truncated"]
    assert context["metadata"]["truncated_sections"]


def test_no_reference_or_evaluator_reads_and_small_missing_workspace_fallback(tmp_path, monkeypatch):
    import datapatch.context as module
    _model(tmp_path, "models/report.sql", "select 1 as amount")
    for folder in ("solution", "tests", "evaluator", "models/tests"):
        _model(tmp_path, f"{folder}/answer.sql", "SECRET_REFERENCE_ANSWER")
    original = module._read_public_text
    touched = []
    def audited(path, root, limit=200_000):
        touched.append(path.relative_to(root).as_posix())
        assert not set(path.relative_to(root).parts) & {"solution", "tests", "evaluator"}
        return original(path, root, limit)
    monkeypatch.setattr(module, "_read_public_text", audited)
    context = build_task_context(Workspace(tmp_path), "Repair models/report.sql; do not inspect solution/answer.sql or tests/answer.sql")
    assert "SECRET_REFERENCE_ANSWER" not in json.dumps(context)
    assert touched == ["models/report.sql"]
    class MissingWorkspace:
        root = tmp_path / "missing"
        project_dir = root
        database_path = root / "warehouse.duckdb"
        def list_files(self):
            return {"files": ["models/report.sql", "tests/answer.sql"]}
    fallback = build_task_context(MissingWorkspace(), "Investigate finance totals")
    assert fallback["target"] is None
    assert fallback["candidate_files"] == ["models/report.sql"]
    assert len(json.dumps(fallback)) < 3000
def test_readme_is_retained_when_short_ticket_does_not_identify_a_model(tmp_path):
    from datapatch.context import build_task_context
    (tmp_path / "models").mkdir()
    (tmp_path / "models/report.sql").write_text("select 1", encoding="utf-8")
    contract = "Exactly one row for every refund, including cancelled orders."
    (tmp_path / "README.md").write_text(contract, encoding="utf-8")
    context = build_task_context(tmp_path, "Repair incorrect coverage")
    assert context["metadata"]["target_found"] is False
    assert context["readme"]["content"] == contract

