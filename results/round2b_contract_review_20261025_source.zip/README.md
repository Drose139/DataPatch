# DataPatch

面向数据工程工单的代码修复与验证 Agent。给它一个 dbt/DuckDB 项目和工单，它读取代码、探查数据、修改模型、运行检查，输出可审阅的补丁、执行轨迹和独立验收结果。

**项目提供真实 DeepSeek 调用、12 个可复现任务、4 种实验配置、中文工作台和公开基准适配。** 修复交付包含 SQL 补丁、前后数据变化、业务检查与完整运行记录。

第一版验收后已对照十余个相关开源项目，按数据证据、语义复核、离线结果审计分三轮改进。[调研与迭代验收](docs/IMPROVEMENTS.md)记录采用理由与实际结果；[完整评测](docs/RESULTS.md)保留所有失败。

## 运行

已配置的本机环境：

```powershell
pwsh -File scripts/start.ps1
```

打开 <http://127.0.0.1:8000>。选择任务和模式，再启动运行。历史记录可以直接回放，不消耗模型 API；界面会明确标注回放来源。

全新环境（Python 3.11+，推荐 3.12）：

```powershell
pwsh -File scripts/setup.ps1
```

在 `.env` 设置 `DEEPSEEK_API_KEY`，再运行启动脚本。密钥只在服务端使用；`.env` 已忽略提交。运行和评测会产生模型 API 费用，估算价格与预算上限均可在 `.env` 调整。

Linux/macOS：

```bash
python3 -m venv .venv
.venv/bin/python -m pip install -r requirements.lock
.venv/bin/python -m pip install -e . --no-deps
cp .env.example .env
# Edit .env locally, then:
.venv/bin/python -m datapatch.cli serve
```

容器方式：`docker compose up --build`。当前交付机器没有 Docker，因此容器配置未在该机实测；已验证的是 Windows 本地执行方式。Native 模式面向本项目的可信 SQL 工程，不是操作系统级沙盒。网页默认只监听本机地址。

## 演示内容

- 订单、支付、明细多表关联造成的金额放大。
- 退款记录遗漏与零分母比率。
- UTC 与业务时区的日界错误。
- 同一人的多账号归并与复购统计。
- 增量模型重跑幂等性。
- 新建客户净收入数据集市。

每类包含 `dev` 和 `holdout` 两个固定种子数据集。**holdout 是相同业务问题的新数据，不代表未知任务或跨行业泛化。** Agent 只能访问生成的工作区；Python 参考计算与最终验收器不在其工具路径内。

![真实运行的数据变化证据](docs/screenshots/workbench-evidence.png)

## 架构与实验模式

```text
FastAPI / CLI
     │
 RunService ── run.json + events.jsonl + patch.diff + data_evidence.json
     │
 DeepSeek tool loop
     ├─ file reads / SQL exploration / model writes / dbt
     ├─ schema + model dependency tools
     ├─ visible business contracts + bounded repair
     └─ one budgeted candidate review (verified)
     │ agent stops
 Independent evaluator ── Python oracle / source integrity / replay checks
     │
 Offline audit ── protocol / score / usage / summary / archived source
```

| 模式 | 行为 |
|---|---|
| baseline | 一次模型调用生成补丁；不获取执行反馈 |
| react | 通用文件、SQL、dbt 工具循环 |
| context | react 加表结构和模型依赖上下文及工具 |
| verified | context 加可见契约、交付检查和预算内一次候选语义复核；将反馈交还执行器 |

所有模式最后都由同一执行器构建、由同一独立验收器评分。最终验收结果不会回传 Agent。可见检查也存在于 dbt 工程中，普通 Agent 可以通过 `dbt test/build` 获取它们；专用模式不垄断测试信息。

工作台「数据变化」将修复前后行数、schema、有效业务键上的新增／移除／变更样本与规则状态并排展示。变化用于解释影响，正确性由独立验收判断。语义复核使用同一模型的独立上下文，计入最大调用数；其意见可供修正，不能代替验收。

## 真实评测

```powershell
.\.venv\Scripts\python.exe -m datapatch.cli eval --modes react context verified --repeats 3 --workers 3 --max-steps 16 --name my_evaluation
```

协议在第一条请求前保存：任务、模型、预算、重复次数、源代码摘要；原始记录、错误与失败不删除。结果写在 `artifacts/evaluations/`，逐次运行在 `artifacts/runs/<run_id>/`。费用是配置单价的保守估算，服务商实际账单为准。

交付结果见 [评测报告](docs/RESULTS.md)。对照关注完整任务成功、重复一致性、运行成本与耗时；小样本不预设显著提升，也不承诺专用模式一定更强。

外部 data-eng-bench 适配、固定上游版本、下载校验和本地复现边界见 [公开基准说明](docs/PUBLIC_BENCHMARK.md)。该适配的 Native 子集结果不称为官方 Harbor 全量榜单成绩。

## 需要看懂和修改的部分

- [代码阅读与修改清单](docs/CODE_READING.md)：关键函数、建议亲手改的两处、验证方式。
- [面试讲解](docs/INTERVIEW.md)：90 秒与 3 分钟讲法、技术追问、成果边界。
- [三分钟演示](docs/DEMO.md)：真实运行与已记录运行回放的操作顺序。
- [调研和三轮改进](docs/IMPROVEMENTS.md)：来源、取舍、每轮验收与效果。

核心文件：`agent.py` 负责工具循环；`workspace.py` 负责执行；`review.py` 负责候选复核；`evidence.py` 负责数据变化；`fixtures.py` 负责数据与独立参考计算；`evaluation.py`／`audit.py` 负责实验与报告核验；`service.py` 负责持久化。

## 测试

```powershell
.\.venv\Scripts\python.exe -m pytest -q
```

测试覆盖原始缺陷确实失败、独立修复后逐行正确、数据不可篡改、增量重复运行、工具边界、验证反馈循环、统计定义和网页 API。测试替身只用于软件测试，不进入真实模型评测或成品回放。

## 数据与开源说明

本项目原始代码采用 MIT License。自建零售数据为固定随机种子生成，包含刻意设计的边界条件，不使用真实个人信息。

外部数据工程基准来自 [Snowflake-Labs/data-eng-bench](https://github.com/Snowflake-Labs/data-eng-bench)，遵循其 Apache-2.0 与 NOTICE。外部大文件、密钥、参考解法和本地运行目录不纳入源码提交。第三方来源及复现条件见 `docs/PUBLIC_BENCHMARK.md`。
