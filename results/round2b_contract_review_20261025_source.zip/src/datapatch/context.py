"""Task-focused public context; no reference solutions or evaluator reads."""
from __future__ import annotations

from collections import Counter, deque
import json
from pathlib import Path
import re
from typing import Any

MAX_CONTEXT_CHARS = 24_000
_FORBIDDEN = {"solution", "solutions", "test", "tests", "checks", "evaluator", "evaluation", "oracle", "ground_truth", "target", "logs", "dbt_packages", ".git"}
_STOP = set("the and this that with from into for are all not model models table tables columns column task fix broken correct output create return report project sql dbt duckdb snowflake app data using have should must existing available following query before after order run select instruction required requirements expected path file where when then else end null cast group join left inner full sum count desc asc case as on to is in by a an of it be at or per its use new only than will your name read build type true false information".split())


def _allowed(path: Path, root: Path) -> bool:
    try:
        relative = path.resolve().relative_to(root.resolve())
    except (ValueError, OSError):
        return False
    return not any(part.lower() in _FORBIDDEN or part.startswith(".") for part in relative.parts)


def _read_public_text(path: Path, root: Path, limit: int = 200_000) -> str:
    if not _allowed(path, root):
        raise ValueError("Context source is outside the public project assets")
    with path.open(encoding="utf-8", errors="replace") as stream:
        return stream.read(limit)


def _refs(sql: str) -> list[str]:
    refs = re.findall(r"\bref\s*\(\s*['\"]([^'\"]+)['\"]", sql, re.I)
    refs += [table for _, table in re.findall(r"\bsource\s*\(\s*['\"]([^'\"]+)['\"]\s*,\s*['\"]([^'\"]+)['\"]", sql, re.I)]
    return list(dict.fromkeys(refs))


def _terms(text: str) -> list[str]:
    words = re.findall(r"[a-zA-Z][a-zA-Z0-9_]*", text.lower())
    words = [piece for word in words for piece in word.split("_") if len(piece) >= 4 and piece not in _STOP]
    return [word for word, _ in Counter(words).most_common(8)]


def _size(value: dict) -> int:
    return len(json.dumps(value, ensure_ascii=False))


def _finish(context: dict) -> dict:
    meta = context["metadata"]
    # Budget priority: target SQL, README, bounded lineage, focused schema.
    while _size(context) > MAX_CONTEXT_CHARS - 80:
        if context.get("schema", {}).get("tables"):
            context["schema"]["tables"].popitem()
            meta["truncated_sections"].append("schema")
        elif context.get("lineage", {}).get("nodes"):
            context["lineage"]["nodes"].pop()
            meta["truncated_sections"].append("lineage")
        elif context.get("readme", {}).get("content"):
            content = context["readme"]["content"]
            excess = _size(context) - (MAX_CONTEXT_CHARS - 100)
            context["readme"]["content"] = content[:max(0, len(content) - max(excess, 200))]
            context["readme"]["truncated"] = True
            meta["truncated_sections"].append("readme")
        elif context.get("target", {}).get("sql"):
            content = context["target"]["sql"]
            excess = _size(context) - (MAX_CONTEXT_CHARS - 100)
            context["target"]["sql"] = content[:max(0, len(content) - max(excess, 200))]
            context["target"]["truncated"] = True
            meta["truncated_sections"].append("target_sql")
        else:
            break
        meta["truncated_sections"] = list(dict.fromkeys(meta["truncated_sections"]))
    meta["serialized_chars"] = _size(context)
    meta["serialized_chars"] = _size(context)
    return context


def _schema(database: Path | None, names: set[str], terms: list[str]) -> dict:
    result: dict[str, Any] = {"tables": {}, "source": "live DuckDB information_schema; metadata only", "selection": "exact target/upstream names first, then business-term matches", "truncated": False}
    if database is None or not database.exists():
        result["note"] = "Use search_schema with the target/ref names after the warehouse is ready."
        return result
    try:
        import duckdb
        with duckdb.connect(str(database), read_only=True) as connection:
            tables = connection.execute("select table_schema, table_name from information_schema.tables where table_schema not in ('information_schema','pg_catalog')").fetchall()
            ranked = []
            for schema, table in tables:
                if any(token in table.lower() for token in ("ground_truth", "solution", "oracle", "gold_answer", "evaluator")):
                    continue
                name = table.lower()
                score = 100 if name in names else sum(3 for word in terms if word in name)
                if score:
                    ranked.append((score, schema, table))
            ranked.sort(key=lambda item: (-item[0], item[1], item[2]))
            result["matched_tables"] = len(ranked)
            result["truncated"] = len(ranked) > 8
            for _, schema, table in ranked[:8]:
                columns = connection.execute("select column_name, data_type from information_schema.columns where table_schema=? and table_name=? order by ordinal_position", [schema, table]).fetchall()
                result["tables"][f"{schema}.{table}"] = {"columns": [{"name": col, "type": kind} for col, kind in columns[:60]], "column_count": len(columns), "truncated": len(columns) > 60}
    except Exception as exc:
        result["note"] = f"Focused schema unavailable: {str(exc)[:200]}; use search_schema with target/ref names."
    return result


def build_task_context(workspace: Any, instruction: str, focus_model: str | None = None) -> dict:
    """Return <=24k JSON characters of task-relevant *public* project assets.

    ``workspace`` can be a Workspace object or a project Path. No task IDs,
    reference patches, model answers, or hidden validators influence selection.
    When a mock/missing workspace cannot be read, return a small tool-guided
    overview instead of eagerly calling unfiltered schema/lineage tools.
    """
    root = Path(getattr(workspace, "root", workspace)).resolve()
    project = Path(getattr(workspace, "project_dir", root)).resolve()
    database = Path(getattr(workspace, "database_path", project / "warehouse.duckdb"))
    context: dict[str, Any] = {"target": None, "lineage": {"nodes": [], "source": "focused parsed dbt refs; upstream only", "truncated": False}, "schema": {"tables": {}}, "guidance": [], "metadata": {"budget_chars": MAX_CONTEXT_CHARS, "sources": [], "truncated_sections": [], "selection": "instruction paths/model names only; no task-ID rules"}}
    try:
        paths = [path for path in sorted((project / "models").rglob("*.sql")) if path.is_file() and _allowed(path, root)]
    except OSError:
        paths = []
    normalized = instruction.replace("\\", "/").lower()
    path_mentions = re.findall(r"[\w./:\-]+\.sql", normalized)
    ranked = []
    for path in paths:
        relative = path.relative_to(root).as_posix()
        project_relative = path.relative_to(project).as_posix()
        score, reason = 0, ""
        if focus_model and (Path(focus_model.replace("\\", "/")).stem.lower() == path.stem.lower()):
            score, reason = 1000, "explicit focus_model"
        for mention in path_mentions:
            if mention.endswith(relative.lower()) or mention.endswith(project_relative.lower()):
                if score < 800:
                    score, reason = 800 + min(len(project_relative), 100), "explicit SQL path in instruction"
            elif mention.rsplit("/", 1)[-1] == path.name.lower() and score < 700:
                score, reason = 700, "explicit SQL filename in instruction"
        if re.search(r"(?<![\w])" + re.escape(path.stem.lower()) + r"(?![\w])", normalized) and score < 600:
            score, reason = 600, "exact model name in instruction"
        if score:
            ranked.append((score, relative, path, reason))
    ranked.sort(key=lambda entry: (-entry[0], entry[1]))
    terms = _terms(instruction)
    # Business requirements are needed even if the short ticket does not name
    # an existing model. In particular the independent review gets no executor
    # conversation, so a tool-read README cannot substitute for this context.
    for readme in dict.fromkeys([project / "README.md", root / "README.md"]):
        if readme.is_file() and _allowed(readme, root):
            try:
                document = _read_public_text(readme, root)
                context["readme"] = {"path": readme.relative_to(root).as_posix(), "content": document[:8000], "source_chars": len(document), "truncated": len(document) > 8000}
                context["metadata"]["sources"].append(readme.relative_to(root).as_posix())
                if len(document) > 8000:
                    context["metadata"]["truncated_sections"].append("readme")
                break
            except (OSError, ValueError):
                pass
    if not ranked:
        available = [path.relative_to(root).as_posix() for path in paths]
        if not available and callable(getattr(workspace, "list_files", None)):
            try:
                available = [value for value in workspace.list_files().get("files", []) if str(value).endswith(".sql") and not {part.lower() for part in Path(value).parts} & _FORBIDDEN]
            except Exception:
                available = []
        available.sort(key=lambda value: (-sum(word in value.lower() for word in terms), value))
        context["candidate_files"] = available[:12]
        context["guidance"] = ["No existing target model was identified. Use list_files/read_file to locate the requested model before querying.", f"Use search_schema with specific business terms or discovered ref names (suggestions: {', '.join(terms[:4]) or 'model/ref name'}). Do not request the full warehouse schema."]
        context["metadata"]["target_found"] = False
        return _finish(context)
    _, relative, target, reason = ranked[0]
    try:
        sql = _read_public_text(target, root)
    except (OSError, ValueError):
        context["guidance"] = [f"Target appears to be {relative}; use read_file to inspect it."]
        return _finish(context)
    context["target"] = {"model": target.stem, "path": relative, "sql": sql, "source_chars": len(sql), "truncated": False, "identified_by": reason}
    context["metadata"].update({"target_found": True, "sources": [*context["metadata"]["sources"], relative]})
    if len(ranked) > 1:
        context["other_mentions"] = [entry[1] for entry in ranked[1:4]]
    # A bounded upstream traversal gives get_lineage(target)'s relevant refs and
    # paths without reading thousands of downstream/unrelated SQL files.
    index = {path.stem.lower(): path for path in paths}
    queue = deque([(target, sql, 0)])
    seen: set[str] = set()
    names: set[str] = set()
    while queue and len(context["lineage"]["nodes"]) < 6:
        node_path, node_sql, depth = queue.popleft()
        if node_path.stem in seen:
            continue
        seen.add(node_path.stem)
        refs = _refs(node_sql)
        names.update(name.lower() for name in refs)
        names.add(node_path.stem.lower())
        context["lineage"]["nodes"].append({"model": node_path.stem, "path": node_path.relative_to(root).as_posix(), "upstream": refs[:20]})
        source_path = node_path.relative_to(root).as_posix()
        if source_path not in context["metadata"]["sources"]:
            context["metadata"]["sources"].append(source_path)
        if depth < 2:
            for ref in refs[:10]:
                upstream = index.get(ref.lower())
                if upstream and upstream.stem not in seen:
                    try:
                        queue.append((upstream, _read_public_text(upstream, root), depth + 1))
                    except (OSError, ValueError):
                        pass
    context["lineage"]["truncated"] = bool(queue)
    if queue:
        context["metadata"]["truncated_sections"].append("lineage")
    names.update(name.lower().split(".")[-1].strip('"') for name in re.findall(r"\b(?:from|join)\s+([\w.\"]+)", sql, re.I) if name.lower() not in {"select", "ref", "source"})
    context["schema"] = _schema(database, names, terms)
    if context["schema"].get("truncated"):
        context["metadata"]["truncated_sections"].append("schema")
    context["guidance"] = ["The target SQL is preloaded. Inspect only missing upstream details, then make a scoped model edit and run the selected model.", "Schema is filtered to target/ref names and business terms. Visible tests and the final evaluator are not included here."]
    return _finish(context)
