# 评测报告离线审计

审计读取已有 JSON 和源码快照，不调用模型、不重跑 dbt、不执行归档代码，也不修改原报告。入口是 `datapatch.audit.audit_report()` / `audit_reports()`；命令行使用 `scripts/audit_results.py`。当前模块先以 `scripts/audit_draft.py` 暂存，待运行中评测封存后才落入核心源码。

```powershell
.venv/Scripts/python.exe scripts/audit_results.py artifacts/evaluations --output artifacts/audits/final.json
```

输出顶层为 `audit`，包含 `passed`、`errors`、`warnings`、`checks`、逐报告结果和明确排除的报告。存在 error 时命令退出码为 1。warning 表示证据缺失或历史格式受限；不能把它解释为相应证据已经核验通过。

检查覆盖以下可从原始记录直接重算的项目：

- `planned_trials`、记录数、任务 × 模式 × 重复次数的完整组合，以及重复的 `run_id` / 组合。
- 通过任务必须执行完成且最终 build 成功；计数、耗时和估算费用非负，token 加和正确。
- 使用正式 `evaluation.summarize(records)` 重算汇总，逐模式检查通过率、调用数、token、费用和耗时等字段。
- 对公开 data-eng-bench 报告，核对 `raw_verifier` 的二元 reward、退出码、组件全部通过与最终 passed 一致；核对组件列表和原始 stdout，要求 pytest 的实际执行摘要，避免把“直接执行测试文件但未运行测试”计成通过。
- 对存在的源码 zip 核验归档 SHA-256、manifest 每个文件的 SHA-256、核心文件规范摘要与报告绑定。manifest 同时兼容 `files: {path: hash}` 和旧版 `files: [{path, sha256}]`。

公开报告使用 `planned_task_ids` 作为计划范围；本地合成报告使用 `task_ids`。单次协议缺少 `repeat` 时会明确 warning 并按 0 核验。无法获得 `raw_verifier`、原始 stdout、源码 zip 或源摘要时也会明确 warning，不生成相应的“证据已通过”声明。旧快照没有 manifest 时仍可根据归档中的 `src/datapatch/*.py` 与报告核验核心摘要，但无法核验逐文件 manifest 声明。

`*_unamended.json` 是保留的历史原记录，默认明确排除。它不能与修订后的正式报告重复计为额外实验。需要检查历史问题时显式执行：

```powershell
.venv/Scripts/python.exe scripts/audit_results.py artifacts/evaluations --include-unamended --output artifacts/audits/history.json
```

历史未修订报告中已知的“执行失败但旧 verification 仍为 passed”会使审计失败，这是预期结果。完整审计应在评测封存后运行；预审计可明确排除仍在写入的批次，但须在输出列出排除项，不能据此宣称整轮验收已完成。

审计通过只说明所检查的记录、汇总与归档证据一致。它不证明业务验收器覆盖充分，也不能消除公开开发题重复调试、样本少或运行环境差异造成的评测限制。
